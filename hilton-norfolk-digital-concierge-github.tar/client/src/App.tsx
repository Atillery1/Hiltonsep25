import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import DiningPage from "@/pages/DiningPage";
import AmenitiesPage from "@/pages/AmenitiesPage";
import TransitPage from "./pages/TransitPage";
import ExplorePage from "@/pages/ExplorePage";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/dining" component={DiningPage} />
      <Route path="/amenities" component={AmenitiesPage} />
      <Route path="/transit" component={TransitPage} />
      <Route path="/explore" component={ExplorePage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
