import AmenityCard from "./AmenityCard";
import { amenities } from "@/lib/hotelData";

export default function AmenitiesSection() {
  return (
    <section id="amenities">
      <div className="space-y-8">
        {amenities.map((amenity) => (
          <AmenityCard key={amenity.id} amenity={amenity} />
        ))}
      </div>
    </section>
  );
}
