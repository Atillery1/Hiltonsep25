import { MapPin, Clock, ShoppingBag, Dumbbell, Waves, Laptop, Wifi } from "lucide-react";
import { Amenity } from "@/lib/hotelData";
import { isAmenityOpen } from "@/lib/utils";

interface AmenityCardProps {
  amenity: Amenity;
}

export default function AmenityCard({ amenity }: AmenityCardProps) {
  // Function to get background gradient and colors based on amenity type
  const getStyles = () => {
    switch (amenity.iconType) {
      case "ShoppingBag":
        return {
          gradient: "from-blue-50 to-blue-100",
          iconColor: "text-blue-500",
          accentColor: "bg-blue-500",
          hoverColor: "group-hover:border-blue-500"
        };
      case "Pool":
        return {
          gradient: "from-cyan-50 to-cyan-100",
          iconColor: "text-cyan-500",
          accentColor: "bg-cyan-500",
          hoverColor: "group-hover:border-cyan-500"
        };
      case "Dumbbell":
        return {
          gradient: "from-red-50 to-red-100",
          iconColor: "text-red-500",
          accentColor: "bg-red-500",
          hoverColor: "group-hover:border-red-500"
        };
      case "Laptop":
        return {
          gradient: "from-amber-50 to-amber-100",
          iconColor: "text-amber-500",
          accentColor: "bg-amber-500",
          hoverColor: "group-hover:border-amber-500"
        };
      case "Wifi":
        return {
          gradient: "from-green-50 to-green-100",
          iconColor: "text-green-500",
          accentColor: "bg-green-500",
          hoverColor: "group-hover:border-green-500"
        };
      default:
        return {
          gradient: "from-gray-50 to-gray-100",
          iconColor: "text-gray-500",
          accentColor: "bg-gray-500",
          hoverColor: "group-hover:border-gray-500"
        };
    }
  };

  const styles = getStyles();
  const isOpen = isAmenityOpen(amenity);

  return (
    <div className={`group shadow-lg bg-white rounded-lg overflow-hidden border-2 border-transparent ${styles.hoverColor} transition-all duration-300 transform hover:-translate-y-2 hover:shadow-xl`}>
      <div className={`h-28 bg-gradient-to-br ${styles.gradient} flex items-center px-6 relative overflow-hidden`}>
        {/* Decorative elements */}
        <div className={`absolute -right-8 -top-8 w-16 h-16 rounded-full opacity-20 ${styles.accentColor}`}></div>
        <div className={`absolute -left-8 -bottom-8 w-12 h-12 rounded-full opacity-10 ${styles.accentColor}`}></div>
        
        {/* Status indicator - don't show for WiFi */}
        {amenity.id !== "wifi" && (
          <div className="absolute top-2 right-2">
            <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
              isOpen 
                ? 'bg-green-100 text-green-800' 
                : 'bg-gray-100 text-gray-800'
            }`}>
              <span className={`h-1.5 w-1.5 rounded-full mr-1 ${
                isOpen ? 'bg-green-500' : 'bg-gray-500'
              }`}></span>
              {isOpen ? 'OPEN' : 'CLOSED'}
            </span>
          </div>
        )}
        
        {/* Main icon and Amenity name in a row */}
        <div className="flex items-center">
          <div className={`rounded-full p-3 ${styles.gradient} shadow-inner mr-4 flex items-center justify-center w-14 h-14`}>
            {amenity.iconType === "ShoppingBag" && <ShoppingBag className={`h-6 w-6 ${styles.iconColor}`} />}
            {amenity.iconType === "Pool" && <Waves className={`h-6 w-6 ${styles.iconColor}`} />}
            {amenity.iconType === "Dumbbell" && <Dumbbell className={`h-6 w-6 ${styles.iconColor}`} />}
            {amenity.iconType === "Laptop" && <Laptop className={`h-6 w-6 ${styles.iconColor}`} />}
            {amenity.iconType === "Wifi" && <Wifi className={`h-6 w-6 ${styles.iconColor}`} />}
          </div>
          <h3 className="font-bold text-2xl text-gray-800">{amenity.name}</h3>
        </div>
      </div>
      
      <div className="p-5">
        <div className="mb-4 flex justify-between items-center">
          <span className={`text-xs font-bold text-white px-3 py-1 rounded-full ${styles.accentColor}`}>HOTEL AMENITY</span>
          <div className={`h-1 w-1/4 rounded ${styles.accentColor}`}></div>
        </div>
        
        <ul className="space-y-3 mb-4">
          <li className="flex items-start">
            <MapPin className={`flex-shrink-0 ${styles.iconColor} mr-2 h-5 w-5 mt-0.5`} /> 
            <div>
              <span className="font-semibold text-gray-700">Location:</span>
              <p className="text-gray-600">{amenity.location}</p>
            </div>
          </li>
          <li className="flex items-start">
            <Clock className={`flex-shrink-0 ${styles.iconColor} mr-2 h-5 w-5 mt-0.5`} /> 
            <div>
              <span className="font-semibold text-gray-700">Hours:</span>
              <p className="text-gray-600">{amenity.hours}</p>
            </div>
          </li>
        </ul>
        
        <div className={`${amenity.id === "wifi" ? "p-4" : "p-3"} bg-gray-50 rounded-lg border border-gray-100 text-sm text-gray-600`}>
          {amenity.id === "wifi" ? (
            <div className="space-y-3">
              <h4 className="text-center font-bold text-base text-green-600 pb-2 mb-2">
                {amenity.description.split('\n')[0]}
              </h4>
              <div className="space-y-3">
                {amenity.description.split('\n').slice(1).map((line, index) => {
                  const [label, value] = line.split(':');
                  
                  return (
                    <div key={index} className="flex items-center">
                      <div className="w-1/2 font-medium text-gray-700">{label}:</div>
                      <div className="w-1/2 font-bold text-gray-800">{value}</div>
                    </div>
                  );
                })}
              </div>
              <div className="mt-2 pt-2 border-t border-green-100 text-xs text-center text-gray-500">
                Connect to enjoy complimentary high-speed internet
              </div>
            </div>
          ) : (
            amenity.description
          )}
        </div>
      </div>
    </div>
  );
}