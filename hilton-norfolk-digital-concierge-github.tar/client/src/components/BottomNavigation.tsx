import { Link, useLocation } from "wouter";
import { Home, Utensils, Package, Car, Compass } from "lucide-react";

export default function BottomNavigation() {
  const [location] = useLocation();
  
  const navItems = [
    {
      label: "Home",
      path: "/",
      icon: Home
    },
    {
      label: "Dining",
      path: "/dining",
      icon: Utensils
    },
    {
      label: "Amenities",
      path: "/amenities", 
      icon: Package
    },
    {
      label: "Transit",
      path: "/transit",
      icon: Car
    },
    {
      label: "Explore",
      path: "/explore",
      icon: Compass
    }
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-[#0F2C59] shadow-lg z-50">
      <div className="flex justify-around max-w-md mx-auto">
        {navItems.map((item) => {
          const isActive = item.path === location;
          const Icon = item.icon;
          
          return (
            <Link href={item.path} key={item.path}>
              <div className={`flex flex-col items-center py-2 px-1 ${
                isActive ? "text-[#DBA53A]" : "text-white"
              }`}>
                <div className={`relative rounded-full p-1 ${
                  isActive ? "bg-[#DBA53A]/20" : "bg-transparent"
                }`}>
                  <Icon className={`h-5 w-5 ${
                    isActive ? "text-[#DBA53A]" : "text-white"
                  }`} />
                </div>
                <span className="text-[10px] font-medium mt-1 whitespace-nowrap">{item.label}</span>
                {isActive && <div className="h-1 w-5 bg-[#DBA53A] rounded-full mt-0.5"></div>}
              </div>
            </Link>
          );
        })}
      </div>
      {/* Add some safe area padding for iOS */}
      <div className="h-[env(safe-area-inset-bottom, 0px)]"></div>
    </div>
  );
}