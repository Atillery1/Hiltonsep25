import { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { ExploreCategory, ExploreListing } from '@/lib/exploreData';
import ExploreCategoryIcon from './ExploreCategoryIcon';
import ExploreListingCard from './ExploreListingCard';

interface ExploreCategoryAccordionProps {
  category: ExploreCategory;
  listings: ExploreListing[];
  isInitiallyOpen?: boolean;
}

export default function ExploreCategoryAccordion({ 
  category, 
  listings,
  isInitiallyOpen = false 
}: ExploreCategoryAccordionProps) {
  const [isOpen, setIsOpen] = useState(isInitiallyOpen);
  
  const toggleOpen = () => {
    setIsOpen(!isOpen);
  };
  
  const getGradientColors = () => {
    switch (category.color) {
      case 'amber':
        return 'from-amber-50 to-amber-100';
      case 'red':
        return 'from-red-50 to-red-100';
      case 'green':
        return 'from-green-50 to-green-100';
      case 'blue':
        return 'from-blue-50 to-blue-100';
      case 'purple':
        return 'from-purple-50 to-purple-100';
      case 'teal':
        return 'from-teal-50 to-teal-100';
      case 'cyan':
        return 'from-cyan-50 to-cyan-100';
      case 'orange':
        return 'from-orange-50 to-orange-100';
      case 'indigo':
        return 'from-indigo-50 to-indigo-100';
      case 'violet':
        return 'from-violet-50 to-violet-100';
      case 'brown':
        return 'from-amber-50 to-orange-100';
      case 'pink':
        return 'from-pink-50 to-pink-100';
      case 'gray':
        return 'from-gray-50 to-gray-100';
      default:
        return 'from-gray-50 to-gray-100';
    }
  };
  
  const getBorderColor = () => {
    switch (category.color) {
      case 'amber':
        return 'border-amber-400 hover:border-amber-500';
      case 'red':
        return 'border-red-400 hover:border-red-500';
      case 'green':
        return 'border-green-400 hover:border-green-500';
      case 'blue':
        return 'border-blue-400 hover:border-blue-500';
      case 'purple':
        return 'border-purple-400 hover:border-purple-500';
      case 'teal':
        return 'border-teal-400 hover:border-teal-500';
      case 'cyan':
        return 'border-cyan-400 hover:border-cyan-500';
      case 'orange':
        return 'border-orange-400 hover:border-orange-500';
      case 'indigo':
        return 'border-indigo-400 hover:border-indigo-500';
      case 'violet':
        return 'border-violet-400 hover:border-violet-500';
      case 'brown':
        return 'border-amber-400 hover:border-amber-500';
      case 'pink':
        return 'border-pink-400 hover:border-pink-500';
      case 'gray':
        return 'border-gray-400 hover:border-gray-500';
      default:
        return 'border-gray-400 hover:border-gray-500';
    }
  };
  
  const getTextColor = () => {
    switch (category.color) {
      case 'amber':
        return 'text-amber-700';
      case 'red':
        return 'text-red-700';
      case 'green':
        return 'text-green-700';
      case 'blue':
        return 'text-blue-700';
      case 'purple':
        return 'text-purple-700';
      case 'teal':
        return 'text-teal-700';
      case 'cyan':
        return 'text-cyan-700';
      case 'orange':
        return 'text-orange-700';
      case 'indigo':
        return 'text-indigo-700';
      case 'violet':
        return 'text-violet-700';
      case 'brown':
        return 'text-amber-800';
      case 'pink':
        return 'text-pink-700';
      case 'gray':
        return 'text-gray-700';
      default:
        return 'text-gray-700';
    }
  };
  
  const getBgColor = () => {
    switch (category.color) {
      case 'amber':
        return 'bg-amber-500';
      case 'red':
        return 'bg-red-500';
      case 'green':
        return 'bg-green-500';
      case 'blue':
        return 'bg-blue-500';
      case 'purple':
        return 'bg-purple-500';
      case 'teal':
        return 'bg-teal-500';
      case 'cyan':
        return 'bg-cyan-500';
      case 'orange':
        return 'bg-orange-500';
      case 'indigo':
        return 'bg-indigo-500';
      case 'violet':
        return 'bg-violet-500';
      case 'brown':
        return 'bg-amber-600';
      case 'pink':
        return 'bg-pink-500';
      case 'gray':
        return 'bg-gray-500';
      default:
        return 'bg-gray-500';
    }
  };
  
  return (
    <div 
      id={`category-${category.id}`}
      className={`shadow-lg bg-white rounded-lg overflow-hidden border-2 transition-all duration-300 ${isOpen ? getBorderColor() : 'border-transparent'}`}
    >
      <div 
        className={`h-28 bg-gradient-to-br ${getGradientColors()} flex items-center px-6 relative overflow-hidden cursor-pointer`}
        onClick={toggleOpen}
      >
        {/* Decorative elements */}
        <div className={`absolute -right-8 -top-8 w-16 h-16 rounded-full opacity-20 ${getBgColor()}`}></div>
        <div className={`absolute -left-8 -bottom-8 w-12 h-12 rounded-full opacity-10 ${getBgColor()}`}></div>
        
        {/* Main icon and title in a row */}
        <div className="flex items-center flex-1">
          <div className={`rounded-full p-3 ${getGradientColors()} shadow-inner mr-4 flex items-center justify-center w-14 h-14`}>
            <div className={`${getTextColor()} h-6 w-6 flex items-center justify-center`}>
              <ExploreCategoryIcon iconName={category.icon} />
            </div>
          </div>
          <div className="flex-1">
            <h3 className="font-bold text-xl text-gray-800">{category.name}</h3>
            <p className="text-sm text-gray-600 mt-1">{category.description}</p>
          </div>
          <div className="ml-4">
            {isOpen ? (
              <ChevronUp className={`h-6 w-6 ${getTextColor()}`} />
            ) : (
              <ChevronDown className={`h-6 w-6 ${getTextColor()}`} />
            )}
          </div>
        </div>
      </div>
      
      {isOpen && (
        <div className="p-5 animate-slideDown">
          <div className="mb-4 flex justify-between items-center">
            <span className={`text-xs font-bold text-white px-3 py-1 rounded-full ${getBgColor()}`}>
              {listings.length} LISTINGS
            </span>
            <div className={`h-1 w-1/4 rounded ${getBgColor()}`}></div>
          </div>
          
          <div className="space-y-4">
            {listings.map(listing => (
              <ExploreListingCard 
                key={listing.id} 
                listing={listing} 
                color={category.color}
                iconName={category.icon}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}