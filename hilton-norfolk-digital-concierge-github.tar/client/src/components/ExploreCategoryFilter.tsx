import { ExploreCategory } from '@/lib/exploreData';
import ExploreCategoryIcon from './ExploreCategoryIcon';
import { ChevronDown } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';

interface ExploreCategoryFilterProps {
  categories: ExploreCategory[];
  selectedCategory: string | null;
  onSelectCategory: (categoryId: string | null) => void;
}

export default function ExploreCategoryFilter({
  categories,
  selectedCategory,
  onSelectCategory
}: ExploreCategoryFilterProps) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  
  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleCategoryClick = (categoryId: string) => {
    if (selectedCategory === categoryId) {
      // If already selected, deselect it
      onSelectCategory(null);
    } else {
      // Otherwise select it
      onSelectCategory(categoryId);
      
      // Smooth scroll to category section
      const element = document.getElementById(`category-${categoryId}`);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }
    
    // Close dropdown after selection
    setIsDropdownOpen(false);
  };
  
  const getTextColor = (color: string) => {
    switch (color) {
      case 'amber':
        return 'text-amber-700';
      case 'red':
        return 'text-red-700';
      case 'green':
        return 'text-green-700';
      case 'blue':
        return 'text-blue-700';
      case 'purple':
        return 'text-purple-700';
      case 'teal':
        return 'text-teal-700';
      case 'cyan':
        return 'text-cyan-700';
      case 'orange':
        return 'text-orange-700';
      case 'indigo':
        return 'text-indigo-700';
      case 'violet':
        return 'text-violet-700';
      case 'brown':
        return 'text-amber-800';
      case 'pink':
        return 'text-pink-700';
      case 'gray':
        return 'text-gray-700';
      default:
        return 'text-gray-700';
    }
  };
  
  const getBgColor = (color: string) => {
    switch (color) {
      case 'amber':
        return 'bg-amber-100';
      case 'red':
        return 'bg-red-100';
      case 'green':
        return 'bg-green-100';
      case 'blue':
        return 'bg-blue-100';
      case 'purple':
        return 'bg-purple-100';
      case 'teal':
        return 'bg-teal-100';
      case 'cyan':
        return 'bg-cyan-100';
      case 'orange':
        return 'bg-orange-100';
      case 'indigo':
        return 'bg-indigo-100';
      case 'violet':
        return 'bg-violet-100';
      case 'brown':
        return 'bg-amber-100';
      case 'pink':
        return 'bg-pink-100';
      case 'gray':
        return 'bg-gray-100';
      default:
        return 'bg-gray-100';
    }
  };
  
  const getActiveBgColor = (color: string) => {
    switch (color) {
      case 'amber':
        return 'bg-amber-500';
      case 'red':
        return 'bg-red-500';
      case 'green':
        return 'bg-green-500';
      case 'blue':
        return 'bg-blue-500';
      case 'purple':
        return 'bg-purple-500';
      case 'teal':
        return 'bg-teal-500';
      case 'cyan':
        return 'bg-cyan-500';
      case 'orange':
        return 'bg-orange-500';
      case 'indigo':
        return 'bg-indigo-500';
      case 'violet':
        return 'bg-violet-500';
      case 'brown':
        return 'bg-amber-600';
      case 'pink':
        return 'bg-pink-500';
      case 'gray':
        return 'bg-gray-500';
      default:
        return 'bg-gray-500';
    }
  };
  
  // Find the selected category
  const selectedCategoryObject = selectedCategory 
    ? categories.find(c => c.id === selectedCategory) 
    : null;
  
  return (
    <div className="p-2" ref={dropdownRef}>
      <div className="relative">
        {/* Dropdown Button */}
        <button 
          onClick={() => setIsDropdownOpen(!isDropdownOpen)}
          className={`flex items-center justify-between w-full px-4 py-2 border rounded-lg shadow-sm 
            ${selectedCategory 
              ? `${getBgColor(selectedCategoryObject!.color)} ${getTextColor(selectedCategoryObject!.color)} border-${selectedCategoryObject!.color}-300`
              : 'bg-white border-gray-300 text-gray-700'
            }`}
        >
          <div className="flex items-center">
            {selectedCategory ? (
              <>
                <div className="w-5 h-5 mr-2 flex items-center justify-center">
                  <ExploreCategoryIcon iconName={selectedCategoryObject!.icon} />
                </div>
                <span className="font-medium">{selectedCategoryObject!.name}</span>
              </>
            ) : (
              <span className="font-medium">All Categories</span>
            )}
          </div>
          <ChevronDown className={`ml-2 h-4 w-4 transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} />
        </button>
        
        {/* Dropdown Menu */}
        {isDropdownOpen && (
          <div className="absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-60 overflow-y-auto">
            <div className="p-1">
              {/* "All Categories" option */}
              <button
                className={`flex items-center w-full px-4 py-2 text-left rounded-md hover:bg-gray-100
                  ${!selectedCategory ? 'bg-gray-100 font-medium' : ''}`}
                onClick={() => {
                  onSelectCategory(null);
                  setIsDropdownOpen(false);
                }}
              >
                <span>All Categories</span>
              </button>
              
              {/* Category options */}
              {categories.map(category => (
                <button
                  key={category.id}
                  className={`flex items-center w-full px-4 py-2 text-left rounded-md hover:bg-gray-100
                    ${selectedCategory === category.id ? 'bg-gray-100 font-medium' : ''}`}
                  onClick={() => handleCategoryClick(category.id)}
                >
                  <div className="w-5 h-5 mr-2 flex items-center justify-center">
                    <ExploreCategoryIcon iconName={category.icon} />
                  </div>
                  <span className={selectedCategory === category.id ? getTextColor(category.color) : ''}>{category.name}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}