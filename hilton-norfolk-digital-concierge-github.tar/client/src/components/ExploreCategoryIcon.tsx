import { 
  UtensilsCrossed,
  UtensilsIcon,
  Globe, 
  Beer, 
  Music, 
  Coffee, 
  Store, 
  Map,
  Heart,
  Pizza as PizzaIcon,
  Beef as BeefIcon,
  Fish as FishIcon,
  Salad as SaladIcon,
  IceCream as IceCreamIcon
} from 'lucide-react';

interface ExploreCategoryIconProps {
  iconName: string;
}

export default function ExploreCategoryIcon({ iconName }: ExploreCategoryIconProps) {
  switch (iconName) {
    case 'sandwich':
      return <UtensilsIcon />;
    case 'burger':
      return <BeefIcon />;
    case 'pizza':
      return <PizzaIcon />;
    case 'pasta':
      return <UtensilsIcon />;
    case 'steak':
      return <UtensilsCrossed />;
    case 'salad':
      return <SaladIcon />;
    case 'fish':
      return <FishIcon />;
    case 'taco':
      return <UtensilsIcon />;
    case 'globe':
      return <Globe />;
    case 'beer':
      return <Beer />;
    case 'music':
      return <Music />;
    case 'coffee':
      return <Coffee />;
    case 'icecream':
      return <IceCreamIcon />;
    case 'store':
      return <Store />;
    case 'map':
      return <Map />;
    case 'medical':
      return <Heart />;
    default:
      return <Globe />;
  }
}