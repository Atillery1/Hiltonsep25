import { ExploreListing } from '@/lib/exploreData';
import ExploreCategoryIcon from './ExploreCategoryIcon';

interface ExploreListingCardProps {
  listing: ExploreListing;
  color: string;
  iconName: string;
}

export default function ExploreListingCard({ 
  listing,
  color,
  iconName
}: ExploreListingCardProps) {
  
  const getTextColor = () => {
    switch (color) {
      case 'amber':
        return 'text-amber-700';
      case 'red':
        return 'text-red-700';
      case 'green':
        return 'text-green-700';
      case 'blue':
        return 'text-blue-700';
      case 'purple':
        return 'text-purple-700';
      case 'teal':
        return 'text-teal-700';
      case 'cyan':
        return 'text-cyan-700';
      case 'orange':
        return 'text-orange-700';
      case 'indigo':
        return 'text-indigo-700';
      case 'violet':
        return 'text-violet-700';
      case 'brown':
        return 'text-amber-800';
      case 'pink':
        return 'text-pink-700';
      case 'gray':
        return 'text-gray-700';
      default:
        return 'text-gray-700';
    }
  };
  
  const getLightBgColor = () => {
    switch (color) {
      case 'amber':
        return 'bg-amber-50';
      case 'red':
        return 'bg-red-50';
      case 'green':
        return 'bg-green-50';
      case 'blue':
        return 'bg-blue-50';
      case 'purple':
        return 'bg-purple-50';
      case 'teal':
        return 'bg-teal-50';
      case 'cyan':
        return 'bg-cyan-50';
      case 'orange':
        return 'bg-orange-50';
      case 'indigo':
        return 'bg-indigo-50';
      case 'violet':
        return 'bg-violet-50';
      case 'brown':
        return 'bg-amber-50';
      case 'pink':
        return 'bg-pink-50';
      case 'gray':
        return 'bg-gray-50';
      default:
        return 'bg-gray-50';
    }
  };
  
  const getBorderColor = () => {
    switch (color) {
      case 'amber':
        return 'border-amber-200';
      case 'red':
        return 'border-red-200';
      case 'green':
        return 'border-green-200';
      case 'blue':
        return 'border-blue-200';
      case 'purple':
        return 'border-purple-200';
      case 'teal':
        return 'border-teal-200';
      case 'cyan':
        return 'border-cyan-200';
      case 'orange':
        return 'border-orange-200';
      case 'indigo':
        return 'border-indigo-200';
      case 'violet':
        return 'border-violet-200';
      case 'brown':
        return 'border-amber-200';
      case 'pink':
        return 'border-pink-200';
      case 'gray':
        return 'border-gray-200';
      default:
        return 'border-gray-200';
    }
  };
  
  return (
    <div className={`rounded-lg p-4 ${getLightBgColor()} border ${getBorderColor()} transition-all duration-200 hover:shadow-md`}>
      <div className="flex items-start">
        <div className={`w-8 h-8 rounded-full ${getLightBgColor()} border ${getBorderColor()} flex items-center justify-center mr-3 mt-0.5 flex-shrink-0`}>
          <div className={`h-4 w-4 ${getTextColor()}`}>
            <ExploreCategoryIcon iconName={iconName} />
          </div>
        </div>
        
        <div className="flex-1">
          <div className="flex justify-between items-start">
            <h4 className="font-semibold text-gray-800">{listing.name}</h4>
          </div>
          
          <div className="flex items-center mt-1">
            <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${getLightBgColor()} border ${getBorderColor()} ${getTextColor()}`}>
              {listing.type}
            </span>
          </div>
          
          {listing.description && listing.description.length > 0 && listing.category !== 'onproperty' && (
            <p className="text-sm text-gray-600 mt-2">{listing.description}</p>
          )}
          
          {listing.location && (
            <p className="text-xs text-gray-500 mt-2">{listing.location}</p>
          )}
        </div>
      </div>
    </div>
  );
}