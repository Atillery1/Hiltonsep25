import { useState } from "react";
import { ThumbsUp, ThumbsDown, Send, XCircle } from "lucide-react";

export default function FeedbackSection() {
  const [feedbackState, setFeedbackState] = useState<'initial' | 'positive' | 'negative' | 'submitted'>('initial');
  const [comment, setComment] = useState('');
  
  const handleFeedback = (isPositive: boolean) => {
    setFeedbackState(isPositive ? 'positive' : 'negative');
  };
  
  const handleSubmit = () => {
    // In a real app, you would send the feedback to a server
    // For now, we'll just acknowledge it in the UI
    console.log("Feedback submitted:", feedbackState, comment);
    setFeedbackState('submitted');
  };
  
  const resetFeedback = () => {
    setFeedbackState('initial');
    setComment('');
  };
  
  return (
    <div className="bg-white mt-8 rounded-lg shadow-md p-4 border border-gray-200">
      <h3 className="text-lg font-semibold text-gray-800 mb-3">Is this information helpful?</h3>
      
      {feedbackState === 'initial' && (
        <div className="flex space-x-4">
          <button 
            onClick={() => handleFeedback(true)}
            className="flex items-center space-x-2 py-2 px-4 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 transition-colors"
          >
            <ThumbsUp size={18} />
            <span>Yes, it's helpful</span>
          </button>
          
          <button 
            onClick={() => handleFeedback(false)}
            className="flex items-center space-x-2 py-2 px-4 rounded-lg bg-gray-50 hover:bg-gray-100 text-gray-700 transition-colors"
          >
            <ThumbsDown size={18} />
            <span>No, it needs improvement</span>
          </button>
        </div>
      )}
      
      {(feedbackState === 'positive' || feedbackState === 'negative') && (
        <div className="mt-2">
          <div className="flex items-center mb-2">
            <span className="text-sm text-gray-700 mr-2">
              {feedbackState === 'positive' 
                ? "Thanks! Would you like to share what was most helpful?" 
                : "We're sorry to hear that. How can we improve?"}
            </span>
            <button onClick={resetFeedback} className="text-gray-400 hover:text-gray-600">
              <XCircle size={16} />
            </button>
          </div>
          
          <div className="flex">
            <textarea 
              className="flex-grow border border-gray-300 rounded-l-lg p-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Your comments (optional)"
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows={3}
            />
            <button 
              onClick={handleSubmit}
              className="bg-blue-600 hover:bg-blue-700 text-white rounded-r-lg px-4 flex items-center"
            >
              <Send size={18} />
            </button>
          </div>
        </div>
      )}
      
      {feedbackState === 'submitted' && (
        <div className="bg-green-50 text-green-800 p-3 rounded-lg flex items-center justify-between">
          <span>Thank you for your feedback! We appreciate your input.</span>
          <button onClick={resetFeedback} className="text-green-700 hover:text-green-900">
            <XCircle size={16} />
          </button>
        </div>
      )}
    </div>
  );
}