import mainLogo from "../assets/main-logo.png";

export default function Footer() {
  return (
    <footer className="bg-gray-100 border-t border-gray-200 py-6 mt-auto">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center text-center">
          {/* Hotel Logo and Name */}
          <img 
            src={mainLogo} 
            alt="Hilton Norfolk The Main" 
            className="h-16 w-16 mb-2"
          />
          <h2 className="text-lg font-bold text-[#0F2C59]">Hilton Norfolk The Main</h2>
          <p className="text-sm text-[#DBA53A] font-medium mb-4">NORFOLK, VA</p>
          
          {/* Address */}
          <div className="mb-2">
            <h3 className="text-sm font-semibold text-gray-700">Address</h3>
            <p className="text-sm text-gray-600">100 East Main Street</p>
            <p className="text-sm text-gray-600">Norfolk, VA 23510</p>
          </div>
          
          {/* Phone */}
          <div className="mb-2">
            <h3 className="text-sm font-semibold text-gray-700">Phone</h3>
            <p className="text-sm text-gray-600">(757) 763-6200</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
