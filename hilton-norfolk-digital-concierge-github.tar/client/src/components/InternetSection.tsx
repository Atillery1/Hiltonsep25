import { Wifi, Info, Signal, Laptop } from "lucide-react";

export default function InternetSection() {
  // Function to get styling for the card
  const getCardStyle = () => {
    return {
      gradient: "from-blue-50 to-blue-100",
      iconColor: "text-blue-500",
      accentColor: "bg-blue-500",
      hoverColor: "group-hover:border-blue-500",
      icon: <Wifi className="h-12 w-12" />
    };
  };

  const wifiStyle = getCardStyle();

  return (
    <section id="internet" className="py-8 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="font-['Playfair_Display'] text-3xl font-bold text-[#0F2C59] text-center mb-8">
          Hotel Internet Access
        </h2>
        
        <div className="max-w-2xl mx-auto">
          {/* Wi-Fi Card */}
          <div className={`group shadow-lg bg-white rounded-lg overflow-hidden border-2 border-transparent ${wifiStyle.hoverColor} transition-all duration-300 transform hover:-translate-y-2 hover:shadow-xl`}>
            <div className={`h-48 bg-gradient-to-br ${wifiStyle.gradient} flex flex-col items-center justify-center relative overflow-hidden`}>
              {/* Decorative elements */}
              <div className={`absolute -right-8 -top-8 w-24 h-24 rounded-full opacity-20 ${wifiStyle.accentColor}`}></div>
              <div className={`absolute -left-8 -bottom-8 w-16 h-16 rounded-full opacity-10 ${wifiStyle.accentColor}`}></div>
              
              {/* Icon */}
              <div className={`rounded-full p-6 ${wifiStyle.gradient} shadow-inner`}>
                <span className={wifiStyle.iconColor}>{wifiStyle.icon}</span>
              </div>
              
              {/* Title */}
              <h3 className="font-bold text-2xl mt-4 text-gray-800">Guest Wi-Fi</h3>
            </div>
            
            <div className="p-5">
              <div className="mb-4 flex justify-between items-center">
                <span className={`text-xs font-bold text-white px-3 py-1 rounded-full ${wifiStyle.accentColor}`}>
                  COMPLIMENTARY
                </span>
                <div className={`h-1 w-1/4 rounded ${wifiStyle.accentColor}`}></div>
              </div>
              
              <ul className="space-y-3 mb-4">
                <li className="flex items-start">
                  <Signal className={`flex-shrink-0 ${wifiStyle.iconColor} mr-2 h-5 w-5 mt-0.5`} /> 
                  <div>
                    <span className="font-semibold text-gray-700">Network:</span>
                    <p className="text-gray-600 font-mono bg-gray-50 p-1 rounded mt-1">HILTON HONORS</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <Laptop className={`flex-shrink-0 ${wifiStyle.iconColor} mr-2 h-5 w-5 mt-0.5`} /> 
                  <div>
                    <span className="font-semibold text-gray-700">Login Info:</span>
                    <div className="grid grid-cols-2 gap-2 mt-1">
                      <div className="bg-gray-50 p-2 rounded text-sm">
                        <span className="text-xs text-gray-500 block">USERNAME</span>
                        <span className="font-medium">Last Name</span>
                      </div>
                      <div className="bg-gray-50 p-2 rounded text-sm">
                        <span className="text-xs text-gray-500 block">PASSWORD</span>
                        <span className="font-medium">Room Number</span>
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
              
              <div className="p-3 mt-2 rounded-lg border border-blue-100 bg-blue-50 text-sm">
                <div className="flex items-center">
                  <Info className="h-5 w-5 text-blue-500 mr-2" />
                  <span className="text-blue-800 font-medium">Need help? Dial 0 for assistance</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
