import { useEffect, useState } from "react";
import { Clock, MapPin, Phone, Mail, Menu, X, Info } from "lucide-react";
import { Link } from "wouter";

// Import the logo
import mainLogo from "../assets/main-logo.png";

export default function NewHeader() {
  const [currentTime, setCurrentTime] = useState<string>("");
  const [currentDate, setCurrentDate] = useState<string>("");
  const [infoExpanded, setInfoExpanded] = useState<boolean>(false);

  // Hotel contact information
  const hotelAddress = "100 East Main Street, Norfolk, VA 23510";
  const hotelEmail = "info@themainnorfolk.com";
  const hotelPhone = "(757) 763-6200";

  // Update the time every second
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      
      // Format time with AM/PM
      setCurrentTime(now.toLocaleTimeString([], { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
      }));
      
      // Format date as Month Day, Year - shorter format for mobile
      setCurrentDate(now.toLocaleDateString([], { 
        weekday: 'short',
        month: 'short', 
        day: 'numeric'
      }));
    };
    
    // Initial call
    updateTime();
    
    // Set interval to update every second
    const timeInterval = setInterval(updateTime, 1000);
    
    // Clean up
    return () => clearInterval(timeInterval);
  }, []);

  const toggleInfo = () => {
    setInfoExpanded(!infoExpanded);
  };

  return (
    <header className="bg-[#0F2C59] text-white py-4 shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4">
        {/* Main header content with simple layout */}
        <div className="flex flex-row items-center justify-between">
          {/* Left column - Hotel name styled vertically */}
          <div className="md:flex-1">
            <div className="flex flex-col items-start">
              <h1 className="font-bold text-xl leading-tight font-['Playfair_Display']">Hilton</h1>
              <h2 className="font-bold text-lg leading-tight font-['Playfair_Display']">Norfolk</h2>
              <h3 className="font-bold text-lg leading-tight font-['Playfair_Display'] text-[#DBA53A]">The Main</h3>
            </div>
          </div>
          
          {/* Center column - Large logo */}
          <div className="flex-1 flex justify-center items-center">
            <Link href="/">
              <img 
                src={mainLogo} 
                alt="Hilton Norfolk The Main" 
                className="h-20 w-20 cursor-pointer transform hover:scale-105 transition-transform"
              />
            </Link>
          </div>
          
          {/* Right column - Time and info button */}
          <div className="md:flex-1 flex flex-col items-end">
            {/* Time display */}
            <div className="mb-2">
              <p className="font-medium text-base whitespace-nowrap">{currentTime}</p>
              <p className="text-xs text-gray-300 whitespace-nowrap">{currentDate}</p>
            </div>
            
            {/* Info button */}
            <button 
              onClick={toggleInfo}
              className="text-xs text-right text-[#DBA53A] hover:text-white transition-colors"
              aria-label="Toggle contact information"
            >
              <span className="flex items-center">
                <Info className="h-4 w-4 mr-1" />
                <span>More Details</span>
              </span>
            </button>
          </div>
        </div>
        
        {/* Contact Information - Expandable */}
        <div 
          className={`w-full overflow-hidden transition-all duration-300 ${
            infoExpanded 
              ? "max-h-96 mt-3 opacity-100 border-t border-blue-700 pt-3" 
              : "max-h-0 opacity-0"
          }`}
        >
          <div className="flex flex-col gap-4 text-sm text-center">
            {/* Phone Number (First and most prominent) */}
            <div className="bg-blue-800 p-3 rounded-md">
              <a href={`tel:${hotelPhone.replace(/[^\d]/g, '')}`} className="flex flex-col items-center text-white hover:text-[#DBA53A]">
                <Phone className="h-6 w-6 text-[#DBA53A] mb-1" />
                <p className="font-bold text-lg">{hotelPhone}</p>
                <p className="text-xs text-gray-300">Tap to call</p>
              </a>
            </div>
            
            {/* Contact Icons Row */}
            <div className="flex justify-center gap-8 py-2">
              {/* Email */}
              <a href={`mailto:${hotelEmail}`} className="flex flex-col items-center text-white hover:text-[#DBA53A]">
                <Mail className="h-8 w-8 text-[#DBA53A] mb-1" />
                <span className="text-xs">Email</span>
              </a>
              
              {/* Address/Map */}
              <a 
                href={`https://maps.google.com/?q=${encodeURIComponent(hotelAddress)}`} 
                target="_blank"
                rel="noopener noreferrer"
                className="flex flex-col items-center text-white hover:text-[#DBA53A]"
              >
                <MapPin className="h-8 w-8 text-[#DBA53A] mb-1" />
                <span className="text-xs">Map</span>
              </a>
            </div>
            
            {/* Full Address (Clickable) */}
            <a 
              href={`https://maps.google.com/?q=${encodeURIComponent(hotelAddress)}`}
              target="_blank"
              rel="noopener noreferrer" 
              className="text-center text-sm hover:underline hover:text-[#DBA53A]"
            >
              {hotelAddress}
            </a>
          </div>
        </div>
      </div>
    </header>
  );
}