import { useState } from "react";
import { MapPin, Clock, Utensils, Coffee, Wine, Beer, Globe, Phone, Fish, GlassWater } from "lucide-react";
import { Restaurant } from "@/lib/hotelData";
import { getCurrentMealPeriod } from "@/lib/utils";

interface RestaurantCardProps {
  restaurant: Restaurant;
  isOpen: boolean;
}

export default function RestaurantCard({ restaurant, isOpen }: RestaurantCardProps) {
  const [isExpanded, setIsExpanded] = useState(isOpen);
  
  // Function to get background gradient and colors based on restaurant ID
  const getStyles = () => {
    switch (restaurant.id) {
      case "saltine":
        return {
          gradient: "from-blue-50 to-blue-100",
          iconColor: "text-blue-500",
          accentColor: "bg-blue-500",
          hoverColor: "group-hover:border-blue-500"
        };
      case "varia":
        return {
          gradient: "from-amber-50 to-amber-100",
          iconColor: "text-amber-500",
          accentColor: "bg-amber-500",
          hoverColor: "group-hover:border-amber-500"
        };
      case "grain":
        return {
          gradient: "from-green-50 to-green-100",
          iconColor: "text-green-500",
          accentColor: "bg-green-500",
          hoverColor: "group-hover:border-green-500"
        };
      default:
        return {
          gradient: "from-gray-50 to-gray-100",
          iconColor: "text-gray-500",
          accentColor: "bg-gray-500",
          hoverColor: "group-hover:border-gray-500"
        };
    }
  };
  
  // No longer need the getIcon function as we're rendering icons directly in the layout
  
  const styles = getStyles();

  return (
    <div className={`group shadow-lg bg-white rounded-lg overflow-hidden border-2 border-transparent ${styles.hoverColor} transition-all duration-300 transform hover:-translate-y-2 hover:shadow-xl`}>
      <div className={`h-28 bg-gradient-to-br ${styles.gradient} flex items-center px-6 relative overflow-hidden`}>
        {/* Decorative elements */}
        <div className={`absolute -right-8 -top-8 w-16 h-16 rounded-full opacity-20 ${styles.accentColor}`}></div>
        <div className={`absolute -left-8 -bottom-8 w-12 h-12 rounded-full opacity-10 ${styles.accentColor}`}></div>
        
        {/* Status indicator in the corner with Opens text */}
        <div className="absolute top-2 right-2 flex flex-col items-center">
          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
            isOpen 
              ? 'bg-green-100 text-green-800' 
              : 'bg-red-100 text-red-800'
          }`}>
            <span className={`h-1.5 w-1.5 rounded-full mr-1 ${
              isOpen ? 'bg-green-500' : 'bg-red-500'
            }`}></span>
            {isOpen ? 'OPEN NOW' : 'CLOSED'}
          </span>
          {isOpen && <span className="text-[10px] text-gray-500 mt-1">Serving {getCurrentMealPeriod(restaurant)}</span>}
        </div>
        
        {/* Main icon and Restaurant name in a row */}
        <div className="flex items-center">
          <div className={`rounded-full p-3 ${styles.gradient} shadow-inner mr-4 flex items-center justify-center w-14 h-14`}>
            {restaurant.id === "saltine" && <Fish className={`h-6 w-6 ${styles.iconColor}`} />}
            {restaurant.id === "varia" && <Wine className={`h-6 w-6 ${styles.iconColor}`} />}
            {restaurant.id === "grain" && <Beer className={`h-6 w-6 ${styles.iconColor}`} />}
          </div>
          <h3 className="font-bold text-2xl text-gray-800">{restaurant.name}</h3>
        </div>
      </div>
      
      <div className="p-5">
        <div className="mb-4 flex justify-between items-center">
          <span className={`text-xs font-bold text-white px-3 py-1 rounded-full ${styles.accentColor} flex items-center`}>
            <Utensils className="h-3 w-3 mr-1" />
            RESTAURANT
          </span>
          <button 
            onClick={() => setIsExpanded(!isExpanded)}
            className={`px-3 py-1 text-xs rounded-full border ${isExpanded ? `${styles.accentColor} text-white` : 'border-gray-300 text-gray-500'}`}
          >
            {isExpanded ? 'Hide Details' : 'View Details'}
          </button>
        </div>
        
        {/* Location info with quick contact */}
        <div className="flex items-start mb-4">
          <MapPin className={`flex-shrink-0 ${styles.iconColor} mr-2 h-5 w-5 mt-0.5`} /> 
          <div className="flex-grow">
            <div className="flex justify-between items-start">
              <div>
                <span className="font-semibold text-gray-700">Location:</span>
                <p className="text-gray-600">{restaurant.location}</p>
              </div>
              
              {/* Quick contact buttons with text labels */}
              <div className="flex flex-col space-y-2 ml-2">
                <a 
                  href={`https://${restaurant.website}`}
                  target="_blank" 
                  rel="noopener noreferrer"
                  className={`inline-flex items-center px-3 py-1.5 rounded-md text-xs font-medium ${
                    restaurant.id === "saltine" ? "bg-blue-50 text-blue-600 hover:bg-blue-100" : 
                    restaurant.id === "varia" ? "bg-amber-50 text-amber-600 hover:bg-amber-100" : 
                    restaurant.id === "grain" ? "bg-green-50 text-green-600 hover:bg-green-100" : 
                    "bg-gray-50 text-gray-600 hover:bg-gray-100"
                  } transition-colors`}
                  title={restaurant.website}
                >
                  <Globe className="h-3.5 w-3.5 mr-1" />
                  <span>Website</span>
                </a>
                
                <a 
                  href={`tel:${restaurant.phone.replace(/[^\d]/g, '')}`}
                  className={`inline-flex items-center px-3 py-1.5 rounded-md text-xs font-medium ${
                    restaurant.id === "saltine" ? "bg-blue-50 text-blue-600 hover:bg-blue-100" : 
                    restaurant.id === "varia" ? "bg-amber-50 text-amber-600 hover:bg-amber-100" : 
                    restaurant.id === "grain" ? "bg-green-50 text-green-600 hover:bg-green-100" : 
                    "bg-gray-50 text-gray-600 hover:bg-gray-100"
                  } transition-colors`}
                  title={restaurant.phone}
                >
                  <Phone className="h-3.5 w-3.5 mr-1" />
                  <span>Call</span>
                </a>
              </div>
            </div>
          </div>
        </div>
        
        {isExpanded && (
          <div className="mt-6 border-t border-gray-200 pt-4">
            <h4 className="font-bold text-lg text-gray-800 mb-4 flex items-center">
              <Clock className={`${styles.iconColor} mr-2 h-5 w-5`} />
              Hours of Operation
            </h4>
            
            <div className="space-y-6">
              <div className="space-y-4">
                {restaurant.operatingHours.map((hours, index) => (
                  <div key={index} className="bg-gray-50 p-3 rounded-lg border border-gray-100">
                    <h5 className={`font-semibold ${styles.iconColor} mb-2`}>{hours.title}</h5>
                    {hours.schedule.map((time, idx) => (
                      <p key={idx} className="text-gray-600 text-sm">{time}</p>
                    ))}
                    {hours.note && <p className="text-sm italic text-gray-500 mt-1">{hours.note}</p>}
                  </div>
                ))}
              </div>
              
              <div className="space-y-4">
                {restaurant.happyHour && (
                  <div className={`p-4 rounded-lg ${
                    restaurant.id === "saltine" ? "bg-blue-50 border border-blue-200" :
                    restaurant.id === "varia" ? "bg-amber-50 border border-amber-200" :
                    restaurant.id === "grain" ? "bg-green-50 border border-green-200" :
                    "bg-gray-50 border border-gray-200"
                  }`}>
                    <h5 className="font-semibold text-gray-800 mb-2 flex items-center">
                      <Beer className={`${styles.iconColor} mr-2 h-4 w-4`} />
                      Happy Hour 
                      {restaurant.happyHour.location && (
                        <span className="text-sm italic ml-1"> {restaurant.happyHour.location}</span>
                      )}
                    </h5>
                    {restaurant.happyHour.schedule.map((time, idx) => (
                      <p key={idx} className="text-gray-600 text-sm">{time}</p>
                    ))}
                  </div>
                )}
                
                {restaurant.inRoomDining ? (
                  <div className="bg-[#DBA53A]/10 p-4 rounded-lg border border-[#DBA53A]/30">
                    <h5 className="font-semibold text-gray-800 mb-2 flex items-center">
                      <Utensils className="text-[#DBA53A] mr-2 h-4 w-4" />
                      In-Room Dining
                      {restaurant.inRoomDining.note && (
                        <span className="text-sm italic ml-1"> {restaurant.inRoomDining.note}</span>
                      )}
                    </h5>
                    {restaurant.inRoomDining.schedule.map((time, idx) => (
                      <p key={idx} className="text-gray-600 text-sm">{time}</p>
                    ))}
                  </div>
                ) : (
                  restaurant.noInRoomDining && (
                    <div className="bg-red-50 p-4 rounded-lg border border-red-200">
                      <h5 className="font-semibold text-gray-800 mb-2 flex items-center">
                        <Utensils className="text-red-500 mr-2 h-4 w-4" />
                        In-Room Dining
                      </h5>
                      <p className="text-red-600 text-sm">{restaurant.noInRoomDining}</p>
                    </div>
                  )
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
