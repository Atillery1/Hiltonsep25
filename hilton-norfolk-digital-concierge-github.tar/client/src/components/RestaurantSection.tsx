import RestaurantCard from "./RestaurantCard";
import RestaurantStatusSection from "./RestaurantStatusSection";
import { restaurants } from "@/lib/hotelData";
import { isRestaurantOpen } from "@/lib/utils";
import { Utensils } from "lucide-react";

export default function RestaurantSection() {
  // Check which restaurants are open with actual logic
  const openStatuses: Record<string, boolean> = {};
  restaurants.forEach(restaurant => {
    openStatuses[restaurant.id] = isRestaurantOpen(restaurant);
  });

  return (
    <section id="dining">
      <div className="space-y-8">
        {restaurants.map((restaurant) => (
          <RestaurantCard 
            key={restaurant.id}
            restaurant={restaurant}
            isOpen={openStatuses[restaurant.id] || false}
          />
        ))}
      </div>
    </section>
  );
}
