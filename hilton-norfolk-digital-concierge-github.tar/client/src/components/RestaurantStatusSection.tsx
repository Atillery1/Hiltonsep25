import { useEffect, useState } from "react";
import { 
  Clock, Utensils, Check, X, Coffee, UtensilsCrossed, 
  ChefHat, Beer, Phone, RefreshCcw, MapPin, Globe
} from "lucide-react";
import { restaurants } from "@/lib/hotelData";
import { 
  isRestaurantOpen, 
  isRoomServiceAvailable, 
  getCurrentRoomServiceMenu, 
  getCurrentMealPeriod 
} from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

export default function RestaurantStatusSection() {
  // State to track open status for real-time updates
  const [openStatuses, setOpenStatuses] = useState<Record<string, boolean>>({});
  const [currentMeals, setCurrentMeals] = useState<Record<string, string>>({});
  const [roomServiceStatuses, setRoomServiceStatuses] = useState<Record<string, boolean>>({});
  const [roomServiceMenus, setRoomServiceMenus] = useState<Record<string, string>>({});
  
  // Current time display
  const [currentTime, setCurrentTime] = useState<string>("");
  
  // Update statuses every minute
  useEffect(() => {
    const updateStatuses = () => {
      const now = new Date();
      // Format time string in Eastern Time
      setCurrentTime(now.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true,
        timeZone: 'America/New_York'
      }));
      
      const newOpenStatuses: Record<string, boolean> = {};
      const newCurrentMeals: Record<string, string> = {};
      const newRoomServiceStatuses: Record<string, boolean> = {};
      const newRoomServiceMenus: Record<string, string> = {};
      
      restaurants.forEach(restaurant => {
        newOpenStatuses[restaurant.id] = isRestaurantOpen(restaurant);
        newCurrentMeals[restaurant.id] = getCurrentMealPeriod(restaurant);
        newRoomServiceStatuses[restaurant.id] = isRoomServiceAvailable(restaurant);
        newRoomServiceMenus[restaurant.id] = getCurrentRoomServiceMenu(restaurant);
      });
      
      setOpenStatuses(newOpenStatuses);
      setCurrentMeals(newCurrentMeals);
      setRoomServiceStatuses(newRoomServiceStatuses);
      setRoomServiceMenus(newRoomServiceMenus);
    };
    
    // Initial update
    updateStatuses();
    
    // Set up interval
    const intervalId = setInterval(updateStatuses, 60000); // Update every minute
    
    return () => clearInterval(intervalId);
  }, []);
  
  // Count open restaurants and available room service
  const openCount = Object.values(openStatuses).filter(Boolean).length;
  const roomServiceCount = Object.values(roomServiceStatuses).filter(Boolean).length;
  
  // Function to get restaurant style based on restaurant ID
  const getRestaurantStyle = (id: string) => {
    switch (id) {
      case "saltine":
        return {
          name: "Saltine",
          gradient: "from-blue-50 to-blue-100",
          iconColor: "text-blue-500",
          accentColor: "bg-blue-500",
          hoverColor: "group-hover:border-blue-500",
          icon: <ChefHat className="h-12 w-12" />
        };
      case "varia":
        return {
          name: "Varia",
          gradient: "from-amber-50 to-amber-100",
          iconColor: "text-amber-500",
          accentColor: "bg-amber-500",
          hoverColor: "group-hover:border-amber-500",
          icon: <Coffee className="h-12 w-12" />
        };
      case "grain":
        return {
          name: "Grain",
          gradient: "from-green-50 to-green-100",
          iconColor: "text-green-500",
          accentColor: "bg-green-500",
          hoverColor: "group-hover:border-green-500",
          icon: <Beer className="h-12 w-12" />
        };
      default:
        return {
          name: "Restaurant",
          gradient: "from-gray-50 to-gray-100",
          iconColor: "text-gray-500",
          accentColor: "bg-gray-500",
          hoverColor: "group-hover:border-gray-500",
          icon: <Utensils className="h-12 w-12" />
        };
    }
  };
  
  // Function to update all statuses
  const refreshStatuses = () => {
    const now = new Date();
    // Format time string in Eastern Time for consistency
    setCurrentTime(now.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: true,
      timeZone: 'America/New_York'
    }));
    
    const newOpenStatuses: Record<string, boolean> = {};
    const newCurrentMeals: Record<string, string> = {};
    const newRoomServiceStatuses: Record<string, boolean> = {};
    const newRoomServiceMenus: Record<string, string> = {};
    
    restaurants.forEach(restaurant => {
      newOpenStatuses[restaurant.id] = isRestaurantOpen(restaurant);
      newCurrentMeals[restaurant.id] = getCurrentMealPeriod(restaurant);
      newRoomServiceStatuses[restaurant.id] = isRoomServiceAvailable(restaurant);
      newRoomServiceMenus[restaurant.id] = getCurrentRoomServiceMenu(restaurant);
    });
    
    setOpenStatuses(newOpenStatuses);
    setCurrentMeals(newCurrentMeals);
    setRoomServiceStatuses(newRoomServiceStatuses);
    setRoomServiceMenus(newRoomServiceMenus);
  };
  
  return (
    <div className="bg-white shadow-md rounded-md overflow-hidden">
      <div className="border-b border-gray-100 flex justify-between items-center px-6 py-4">
        <h2 className="font-bold text-lg text-[#0F2C59] flex items-center">
          Open Now
        </h2>
        <div className="text-sm text-gray-500">
          {currentTime}
        </div>
      </div>
      
      {/* Restaurant Status Cards - Simplified version */}
      <div className="p-5">
        <div className="divide-y divide-gray-100">
          {restaurants.map((restaurant) => {
            const isOpen = openStatuses[restaurant.id] || false;
            const hasRoomService = roomServiceStatuses[restaurant.id] || false;
            
            // Find current operating hours for closing time
            // Get current day in Eastern Time for consistency with other time calculations
            const etOptions = { timeZone: 'America/New_York' };
            const etDate = new Date(new Date().toLocaleString('en-US', etOptions));
            const currentDay = etDate.getDay(); // 0 = Sunday, 1 = Monday, etc.
            let closingTime = "";
            
            // Use hardcoded closing times for consistency
            if (restaurant.id === "saltine") {
              closingTime = "11:00 PM";
            } else if (restaurant.id === "varia") {
              closingTime = "10:00 PM";
            } else if (restaurant.id === "grain") {
              // Grain's closing time varies by day of week
              if (currentDay === 5 || currentDay === 6) { // Friday or Saturday
                closingTime = "2:00 AM";
              } else {
                closingTime = "12:00 AM";
              }
            }
            
            // Get next opening time if closed
            let nextOpeningTime = "";
            if (!isOpen) {
              // For simplicity, use the opening time logic from utils.ts
              nextOpeningTime = "Opens soon";
            }
            
            // Get kitchen closing time
            let kitchenClosingTime = "";
            const kitchenHours = restaurant.operatingHours.find(h => 
              h.title.toLowerCase().includes('kitchen')
            );
            
            if (kitchenHours && kitchenHours.schedule.length > 0) {
              // Find applicable schedule for today
              for (const schedule of kitchenHours.schedule) {
                const timeMatch = schedule.match(/(\d+(?::\d+)?\s*(?:AM|PM|am|pm))/i);
                if (timeMatch) {
                  kitchenClosingTime = timeMatch[1];
                  break;
                }
              }
            }
            
            return (
              <div
                key={restaurant.id}
                className={`py-4 flex items-center justify-between ${!isOpen ? 'opacity-60' : ''}`}
              >
                <div>
                  <div className="flex items-center">
                    <h3 className={`font-bold ${isOpen ? 'text-gray-800' : 'text-gray-500'}`}>
                      {restaurant.name}
                    </h3>
                    <span className={`ml-2 px-2 py-0.5 text-xs font-medium ${isOpen 
                      ? 'bg-[#0F2C59] text-white' 
                      : 'bg-gray-200 text-gray-600'}`}
                    >
                      {isOpen ? 'OPEN' : 'CLOSED'}
                    </span>
                  </div>
                  
                  {/* Service Status Line: Closes only */}
                  <div className="flex items-center mt-1 text-xs">
                    {isOpen ? (
                      <span className="text-gray-500">
                        Closes {closingTime}
                      </span>
                    ) : (
                      <span className="text-gray-400">
                        {nextOpeningTime}
                      </span>
                    )}
                  </div>
                </div>
                
                {/* Right side status info */}
                {isOpen && (
                  <div className="text-right">
                    {/* Room service status for Saltine and Varia */}
                    {(restaurant.id === "saltine" || restaurant.id === "varia") && (
                      <div className="text-sm text-[#DBA53A] font-medium">
                        {hasRoomService ? "Room Service Available" : "No Room Service"}
                      </div>
                    )}
                    
                    {/* Only show kitchen closing for Grain */}
                    {restaurant.id === "grain" && kitchenClosingTime && (
                      <div className="text-xs text-gray-500 mt-1">
                        Kitchen closes at {kitchenClosingTime}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
        
        {/* Footer with disclaimer and refresh button */}
        <div className="mt-5 pt-4 border-t border-gray-100">
          <div className="text-xs text-gray-500 mb-2">
            Restaurant hours may change due to business needs. Open/close notifications are based on standard hours.
          </div>
          <div className="flex items-center justify-between">
            <div className="text-xs text-gray-500">
              Updates automatically
            </div>
            <button 
              onClick={refreshStatuses}
              className="text-xs text-[#0F2C59] flex items-center"
            >
              <RefreshCcw className="h-3 w-3 mr-1" />
              Refresh
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}