import { 
  Car, Plane, Train, Bus, 
  ParkingCircle, Lock, Plug, 
  ExternalLink, MapPin, Globe
} from "lucide-react";

interface TransitCardProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  colorScheme: 'blue' | 'cyan' | 'red' | 'amber' | 'green' | 'purple';
}

function TransitCard({ title, icon, children, colorScheme }: TransitCardProps) {
  // Function to get background gradient and colors based on color scheme
  const getStyles = () => {
    switch (colorScheme) {
      case "blue":
        return {
          gradient: "from-blue-50 to-blue-100",
          iconColor: "text-blue-500",
          accentColor: "bg-blue-500",
          hoverColor: "group-hover:border-blue-500"
        };
      case "cyan":
        return {
          gradient: "from-cyan-50 to-cyan-100",
          iconColor: "text-cyan-500",
          accentColor: "bg-cyan-500",
          hoverColor: "group-hover:border-cyan-500"
        };
      case "red":
        return {
          gradient: "from-red-50 to-red-100",
          iconColor: "text-red-500",
          accentColor: "bg-red-500",
          hoverColor: "group-hover:border-red-500"
        };
      case "amber":
        return {
          gradient: "from-amber-50 to-amber-100",
          iconColor: "text-amber-500",
          accentColor: "bg-amber-500",
          hoverColor: "group-hover:border-amber-500"
        };
      case "green":
        return {
          gradient: "from-green-50 to-green-100",
          iconColor: "text-green-500",
          accentColor: "bg-green-500",
          hoverColor: "group-hover:border-green-500"
        };
      case "purple":
        return {
          gradient: "from-purple-50 to-purple-100",
          iconColor: "text-purple-500",
          accentColor: "bg-purple-500",
          hoverColor: "group-hover:border-purple-500"
        };
      default:
        return {
          gradient: "from-gray-50 to-gray-100",
          iconColor: "text-gray-500",
          accentColor: "bg-gray-500",
          hoverColor: "group-hover:border-gray-500"
        };
    }
  };

  const styles = getStyles();
  
  return (
    <div className={`group shadow-lg bg-white rounded-lg overflow-hidden border-2 border-transparent ${styles.hoverColor} transition-all duration-300 transform hover:-translate-y-2 hover:shadow-xl`}>
      <div className={`h-28 bg-gradient-to-br ${styles.gradient} flex items-center px-6 relative overflow-hidden`}>
        {/* Decorative elements */}
        <div className={`absolute -right-8 -top-8 w-16 h-16 rounded-full opacity-20 ${styles.accentColor}`}></div>
        <div className={`absolute -left-8 -bottom-8 w-12 h-12 rounded-full opacity-10 ${styles.accentColor}`}></div>
        
        {/* Main icon and title in a row */}
        <div className="flex items-center">
          <div className={`rounded-full p-3 ${styles.gradient} shadow-inner mr-4 flex items-center justify-center w-14 h-14`}>
            <div className={`${styles.iconColor} h-6 w-6 flex items-center justify-center`}>
              {icon}
            </div>
          </div>
          <h3 className="font-bold text-2xl text-gray-800">{title}</h3>
        </div>
      </div>
      
      <div className="p-5">
        <div className="mb-4 flex justify-between items-center">
          <span className={`text-xs font-bold text-white px-3 py-1 rounded-full ${styles.accentColor}`}>TRANSIT INFO</span>
          <div className={`h-1 w-1/4 rounded ${styles.accentColor}`}></div>
        </div>
        
        <div>
          {children}
        </div>
      </div>
    </div>
  );
}

export default function TransitSection() {
  return (
    <section id="transit">
      <div className="space-y-8">
        {/* Parking Section */}
        <TransitCard 
          title="Hotel Parking" 
          icon={<ParkingCircle className="h-6 w-6" />}
          colorScheme="blue"
        >
          <p className="text-gray-600 mb-4">We offer convenient and flexible parking options:</p>
          
          <div className="space-y-3">
            <div className="flex items-start">
              <Car className="h-5 w-5 text-blue-500 mt-0.5 mr-3 flex-shrink-0" />
              <div>
                <h4 className="font-medium text-gray-800">Valet Parking – $33 per day</h4>
                <p className="text-sm text-gray-600 mt-1">Includes unlimited in/out privileges.</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Car className="h-5 w-5 text-blue-500 mt-0.5 mr-3 flex-shrink-0" />
              <div>
                <h4 className="font-medium text-gray-800">Self-Parking – $18 per day</h4>
                <p className="text-sm text-gray-600 mt-1">Includes unlimited in/out privileges.</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Car className="h-5 w-5 text-blue-500 mt-0.5 mr-3 flex-shrink-0" />
              <div>
                <h4 className="font-medium text-gray-800">Maximum Daily Rate (no in/out access) – $13.00</h4>
                <p className="text-sm text-gray-600 mt-1">Ideal for short-term stays or daytime visitors.</p>
              </div>
            </div>
            
            <div className="border-t border-gray-100 pt-3 mt-3">
              <div className="flex items-start">
                <MapPin className="h-5 w-5 text-blue-500 mt-0.5 mr-3 flex-shrink-0" />
                <div>
                  <h4 className="font-medium text-gray-800">Parking Garage Location</h4>
                  <p className="text-sm text-gray-600 mt-1">The garage is located directly behind the hotel.</p>
                </div>
              </div>
            </div>
            
            <div className="border-t border-gray-100 pt-3 mt-3">
              <h4 className="font-medium text-gray-800 mb-2">Garage Access Details</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-start">
                  <div className="h-5 w-5 flex items-center justify-center text-blue-500 mr-2 font-bold">•</div>
                  <span>3rd Level: Connects to the 2nd Floor Lobby (front desk, restaurants, and guest elevators)</span>
                </li>
                <li className="flex items-start">
                  <div className="h-5 w-5 flex items-center justify-center text-blue-500 mr-2 font-bold">•</div>
                  <span>1st Level: Connects directly to valet and guest elevators</span>
                </li>
                <li className="flex items-start">
                  <Plug className="h-5 w-5 text-blue-500 mt-0.5 mr-2 flex-shrink-0" />
                  <span>EV charging stations available</span>
                </li>
              </ul>
            </div>
            
            <div className="flex items-start mt-4">
              <Lock className="h-5 w-5 text-blue-500 mt-0.5 mr-3 flex-shrink-0" />
              <p className="text-sm text-gray-600">Access to elevators may require a room key after 11:00 PM</p>
            </div>
          </div>
        </TransitCard>
        
        {/* Airport Section */}
        <TransitCard 
          title="Airport" 
          icon={<Plane className="h-6 w-6" />}
          colorScheme="cyan"
        >
          <div className="space-y-2">
            <h4 className="font-medium text-gray-800">Norfolk International Airport (ORF)</h4>
            <p className="text-sm text-gray-600 flex items-start">
              <MapPin className="h-5 w-5 text-cyan-500 mt-0.5 mr-2 flex-shrink-0" />
              2200 Norview Ave, Norfolk, VA 23518
            </p>
            <div className="flex justify-end mt-2">
              <a 
                href="https://www.norfolkairport.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center p-2 rounded-full bg-cyan-50 text-cyan-600 hover:bg-cyan-100 transition-colors"
                title="Norfolk International Airport"
              >
                <Globe className="h-5 w-5" />
              </a>
            </div>
          </div>
        </TransitCard>

        {/* Amtrak Section */}
        <TransitCard 
          title="Amtrak Train" 
          icon={<Train className="h-6 w-6" />}
          colorScheme="red"
        >
          <div className="space-y-2">
            <h4 className="font-medium text-gray-800">Norfolk Amtrak Station</h4>
            <p className="text-sm text-gray-600 flex items-start">
              <MapPin className="h-5 w-5 text-red-500 mt-0.5 mr-2 flex-shrink-0" />
              280 Park Avenue (near Harbor Park)
            </p>
            <div className="flex justify-end mt-2">
              <a 
                href="https://www.amtrak.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center p-2 rounded-full bg-red-50 text-red-600 hover:bg-red-100 transition-colors"
                title="Amtrak"
              >
                <Globe className="h-5 w-5" />
              </a>
            </div>
          </div>
        </TransitCard>

        {/* Combined HRT Section (Light Rail & Bus) */}
        <TransitCard 
          title="Hampton Roads Transit" 
          icon={<Bus className="h-6 w-6" />}
          colorScheme="purple"
        >
          <div className="space-y-4">
            {/* Light Rail Info */}
            <div className="space-y-2 border-b border-purple-100 pb-3">
              <h4 className="font-medium text-gray-800 flex items-center">
                <Train className="h-5 w-5 text-purple-500 mr-2" />
                The Tide Light Rail
              </h4>
              <p className="text-sm text-gray-600">MacArthur Square Station (4-minute walk from hotel)</p>
              
              <div className="mt-3">
                <p className="text-sm font-medium text-gray-700">Light Rail connects to:</p>
                <ul className="space-y-1 mt-1 text-sm text-gray-600">
                  <li className="flex items-start">
                    <div className="h-5 w-5 flex items-center justify-center text-purple-500 mr-2 font-bold">•</div>
                    <span>Norfolk State University (NSU)</span>
                  </li>
                  <li className="flex items-start">
                    <div className="h-5 w-5 flex items-center justify-center text-purple-500 mr-2 font-bold">•</div>
                    <span>Sentara Norfolk General Hospital</span>
                  </li>
                  <li className="flex items-start">
                    <div className="h-5 w-5 flex items-center justify-center text-purple-500 mr-2 font-bold">•</div>
                    <span>Newtown Road Park & Ride</span>
                  </li>
                </ul>
              </div>
            </div>
            
            {/* Bus Service Info */}
            <div className="space-y-2 pt-2">
              <h4 className="font-medium text-gray-800 flex items-center">
                <Bus className="h-5 w-5 text-purple-500 mr-2" />
                HRT Bus Service
              </h4>
              <p className="text-sm text-gray-600">Multiple bus routes throughout Downtown Norfolk and surrounding areas.</p>
            </div>
            
            {/* Website Link */}
            <div className="flex justify-center pt-2">
              <a 
                href="https://gohrt.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center p-2 rounded-full bg-purple-50 text-purple-600 hover:bg-purple-100 transition-colors"
                title="Hampton Roads Transit"
              >
                <Globe className="h-6 w-6" />
              </a>
            </div>
          </div>
        </TransitCard>

        {/* Taxis & Ride Shares Section */}
        <TransitCard 
          title="Taxis & Ride Shares" 
          icon={<Car className="h-6 w-6" />}
          colorScheme="amber"
        >
          <div className="space-y-3">
            <p className="text-sm text-gray-600">Taxis and app-based services are widely available.</p>
            
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <h4 className="font-medium text-gray-800">ZTrip</h4>
                <a 
                  href="https://ztrip.com" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center p-2 rounded-full bg-amber-50 text-amber-600 hover:bg-amber-100 transition-colors"
                  title="ZTrip - Pre-scheduled or on-demand taxis"
                >
                  <Globe className="h-5 w-5" />
                </a>
              </div>
              
              <div className="flex justify-between items-center">
                <h4 className="font-medium text-gray-800">Uber</h4>
                <a 
                  href="https://uber.com" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center p-2 rounded-full bg-amber-50 text-amber-600 hover:bg-amber-100 transition-colors"
                  title="Uber"
                >
                  <Globe className="h-5 w-5" />
                </a>
              </div>
              
              <div className="flex justify-between items-center">
                <h4 className="font-medium text-gray-800">Lyft</h4>
                <a 
                  href="https://lyft.com" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center p-2 rounded-full bg-amber-50 text-amber-600 hover:bg-amber-100 transition-colors"
                  title="Lyft"
                >
                  <Globe className="h-5 w-5" />
                </a>
              </div>
            </div>
            
            <div className="border-t border-gray-100 pt-3 mt-3">
              <h4 className="font-medium text-gray-800">Recommended Pickup Spot:</h4>
              <p className="text-sm text-gray-600 mt-1">Hotel's main entrance or corner of Main St & Granby St</p>
            </div>
          </div>
        </TransitCard>
      </div>
    </section>
  );
}