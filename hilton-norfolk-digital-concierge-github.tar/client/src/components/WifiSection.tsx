import { Wifi, Lock, CreditCard, Users } from "lucide-react";

export default function WifiSection() {
  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8 border border-gray-200">
      <div className="bg-gradient-to-r from-[#0F2C59] to-[#1A3A6C] text-white p-5 flex items-center">
        <div className="rounded-full bg-white/20 p-2 mr-3">
          <Wifi className="h-6 w-6" />
        </div>
        <h2 className="text-xl font-bold">Guest WiFi</h2>
      </div>

      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Free Guest WiFi */}
          <div className="bg-[#F8FAFC] rounded-lg p-5 border border-blue-100">
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                <Wifi className="h-5 w-5 text-blue-600" />
              </div>
              <h3 className="text-lg font-bold text-gray-800">Free Guest WiFi</h3>
            </div>
            
            <div className="space-y-4">
              <p className="text-gray-600">
                Connect to our complimentary high-speed WiFi network throughout the hotel.
              </p>
              
              <div className="bg-white p-4 rounded-md border border-gray-200">
                <h4 className="font-semibold text-gray-700 mb-2">Connection Details:</h4>
                <div className="space-y-3">
                  <div className="flex items-start">
                    <div className="font-medium text-gray-700 w-24">Network:</div>
                    <div className="text-gray-600 font-bold">Hilton Honors</div>
                  </div>
                  <div className="flex items-start">
                    <div className="font-medium text-gray-700 w-24">Password:</div>
                    <div className="text-gray-600">No password required</div>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center text-sm text-gray-500">
                <Users className="h-4 w-4 mr-2 text-blue-500" />
                <span>Supports multiple devices</span>
              </div>
            </div>
          </div>
          
          {/* Premium WiFi */}
          <div className="bg-[#F8FAFC] rounded-lg p-5 border border-amber-100">
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center mr-3">
                <Lock className="h-5 w-5 text-amber-600" />
              </div>
              <h3 className="text-lg font-bold text-gray-800">Premium WiFi</h3>
            </div>
            
            <div className="space-y-4">
              <p className="text-gray-600">
                For enhanced speeds and premium bandwidth, upgrade to our Premium WiFi service.
              </p>
              
              <div className="bg-white p-4 rounded-md border border-gray-200">
                <h4 className="font-semibold text-gray-700 mb-2">Upgrade Options:</h4>
                <div className="space-y-3">
                  <div className="flex items-start">
                    <div className="font-medium text-gray-700 w-24">Daily:</div>
                    <div className="text-gray-600">$14.95 per day</div>
                  </div>
                  <div className="flex items-start">
                    <div className="font-medium text-gray-700 w-24">Weekly:</div>
                    <div className="text-gray-600">$69.95 per week</div>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center text-sm text-gray-500">
                <CreditCard className="h-4 w-4 mr-2 text-amber-500" />
                <span>Purchase available through in-room TV or front desk</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-6 bg-gray-50 p-4 rounded-lg border border-gray-200">
          <h3 className="font-bold text-gray-800 mb-2">Need Help?</h3>
          <p className="text-gray-600">
            If you experience any connectivity issues, please contact our front desk by dialing
            <span className="font-semibold"> 0 </span>
            from your room phone or call <span className="font-semibold">(757) 664-6620</span> for assistance.
          </p>
        </div>
      </div>
    </div>
  );
}