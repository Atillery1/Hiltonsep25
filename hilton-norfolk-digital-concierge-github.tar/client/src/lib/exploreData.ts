export interface ExploreListing {
  id: string;
  name: string;
  category: string;
  type: string;
  description: string;
  location?: string;
  website?: string;
  phone?: string;
}

export interface ExploreCategory {
  id: string;
  name: string;
  icon: string;
  color: string;
  description: string;
}

export const exploreCategories: ExploreCategory[] = [
  {
    id: "onproperty",
    name: "On Property",
    icon: "map",
    color: "blue",
    description: "Dining available at Hilton Norfolk THE MAIN"
  },
  {
    id: "delis",
    name: "Quick Meals & Sandwiches",
    icon: "sandwich",
    color: "amber",
    description: "Fresh, made-to-order sandwiches and quick bites"
  },
  {
    id: "burgers",
    name: "Burgers & Comfort Food",
    icon: "burger",
    color: "red",
    description: "Satisfying burgers and classic comfort dishes"
  },
  {
    id: "pizza",
    name: "Pizza & Casual Italian",
    icon: "pizza",
    color: "green",
    description: "Casual pizza spots and Italian options"
  },
  {
    id: "italian",
    name: "Italian Dining (Sit-Down)",
    icon: "pasta",
    color: "blue",
    description: "Upscale Italian restaurants with refined atmosphere"
  },
  {
    id: "upscale",
    name: "Steak & Upscale Seafood",
    icon: "steak",
    color: "purple",
    description: "Fine dining experiences with premium ingredients"
  },
  {
    id: "healthy",
    name: "Healthy, Brunch & Daytime Cafés",
    icon: "salad",
    color: "teal",
    description: "Nutritious meals and satisfying brunch options"
  },
  {
    id: "seafood",
    name: "Seafood Specialists",
    icon: "fish",
    color: "cyan",
    description: "Fresh seafood and oyster bars"
  },
  {
    id: "mexican",
    name: "Mexican & Tex-Mex",
    icon: "taco",
    color: "orange",
    description: "Flavorful Mexican cuisine and Tex-Mex favorites"
  },
  {
    id: "global",
    name: "Global Flavors",
    icon: "globe",
    color: "indigo",
    description: "International cuisine from around the world"
  },
  {
    id: "breweries",
    name: "Breweries & Chill Bars",
    icon: "beer",
    color: "amber",
    description: "Craft beers and relaxed atmospheres"
  },
  {
    id: "nightlife",
    name: "Nightlife & Party Spots",
    icon: "music",
    color: "violet",
    description: "Energetic nightlife venues and entertainment"
  },
  {
    id: "coffee",
    name: "Coffee, Tea & Sweets",
    icon: "coffee",
    color: "brown",
    description: "Specialty coffee and convenient snacks"
  },
  {
    id: "essentials",
    name: "Essential Services",
    icon: "store",
    color: "gray",
    description: "Convenient services and everyday necessities"
  },
  {
    id: "beauty",
    name: "Beauty & Self-Care",
    icon: "scissors",
    color: "pink",
    description: "Spas, salons, and beauty stores for personal care"
  },
  {
    id: "medical",
    name: "Medical & Emergency Services",
    icon: "medical",
    color: "red",
    description: "Healthcare facilities and emergency services"
  },
  {
    id: "attractions",
    name: "Attractions & Things To Do",
    icon: "map",
    color: "blue",
    description: "Local landmarks, museums, and entertainment"
  }
];

export const exploreListings: ExploreListing[] = [
  // On Property
  {
    id: "saltine-hotel",
    name: "Saltine (1st Floor)",
    category: "onproperty",
    type: "Seafood & Oysters",
    location: "100 E Main St, Norfolk VA 23510",
    description: ""
  },
  
  // Beauty & Self-Care
  {
    id: "sweet-ambiance",
    name: "Sweet Ambiance (MacArthur Center)",
    category: "beauty",
    type: "Perfume Store",
    location: "300 Monticello Ave #4575, Norfolk VA 23510",
    description: ""
  },
  {
    id: "glitz-spa-bar",
    name: "Glitz Spa Bar (MacArthur Center)",
    category: "beauty",
    type: "Spa",
    location: "300 Monticello Ave Suite #294, Norfolk VA 23510",
    description: ""
  },
  {
    id: "varia-hotel",
    name: "Varia (2nd Floor)",
    category: "onproperty",
    type: "Elegant Italian",
    location: "100 E Main St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "grain-hotel",
    name: "Grain (5th Floor)",
    category: "onproperty",
    type: "Rooftop Beer Garden",
    location: "100 E Main St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "town-center-hotel",
    name: "Town Center Cold Pressed (1st Floor)",
    category: "onproperty",
    type: "Coffee & Juice Bar",
    location: "100 E Main St, Norfolk VA 23510",
    description: ""
  },
  
  // Delis & Sandwich Shops
  {
    id: "granby-street-deli",
    name: "Granby Street Deli",
    category: "delis",
    type: "Deli",
    location: "225 Granby St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "the-ten-top",
    name: "The Ten Top",
    category: "delis",
    type: "Deli & Cafe",
    location: "748 Shirley Ave, Norfolk VA 23517",
    description: ""
  },
  {
    id: "field-guide",
    name: "Field Guide (closed)",
    category: "delis",
    type: "Modern Deli",
    location: "429 Granby St, Norfolk VA 23510",
    description: ""
  },

  // Burgers & Comfort Food
  {
    id: "jack-browns",
    name: "Jack Brown's Beer & Burger Joint",
    category: "burgers",
    type: "Burgers & Beer",
    location: "131 Granby St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "hells-kitchen",
    name: "Hell's Kitchen",
    category: "burgers",
    type: "Bar & Grill",
    location: "124 Granby St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "grilled-cheese-bistro",
    name: "The Grilled Cheese Bistro",
    category: "burgers",
    type: "Comfort Food",
    location: "345 Granby St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "hair-of-the-dog",
    name: "Hair of the Dog Eatery",
    category: "burgers",
    type: "Southern Comfort",
    location: "250 Granby St, Norfolk VA 23510",
    description: ""
  },

  // Quick & Easy Pizza & Italian Options
  {
    id: "granby-street-pizza",
    name: "Granby Street Pizza",
    category: "pizza",
    type: "Pizza & Subs",
    location: "235 Granby St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "chichos-pizza",
    name: "Chicho's Pizza (Downtown)",
    category: "pizza",
    type: "Local Pizza",
    location: "320 Granby St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "ynot-italian",
    name: "Ynot Italian (MacArthur Center)",
    category: "pizza",
    type: "Food Court Italian",
    location: "300 Monticello Ave, Norfolk VA 23510",
    description: ""
  },
  {
    id: "sbarro",
    name: "Sbarro (MacArthur Center)",
    category: "pizza",
    type: "Quick Pizza",
    location: "300 Monticello Ave, Norfolk VA 23510",
    description: ""
  },
  {
    id: "charleys-cheesesteaks",
    name: "Charleys Cheesesteaks (MacArthur Center)",
    category: "pizza",
    type: "Cheesesteaks & Flatbreads",
    location: "300 Monticello Ave, Norfolk VA 23510",
    description: ""
  },

  // Italian Dining
  {
    id: "varia",
    name: "Varia (2nd Floor)",
    category: "italian",
    type: "Elegant Italian",
    location: "100 E Main St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "luce",
    name: "Luce",
    category: "italian",
    type: "Upscale Italian",
    location: "245 Granby St, Norfolk VA 23510",
    description: ""
  },

  // Steaks & Upscale Dining
  {
    id: "saltine",
    name: "Saltine (1st Floor)",
    category: "upscale",
    type: "Seafood & Oysters",
    location: "100 E Main St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "brothers",
    name: "Brothers",
    category: "upscale",
    type: "Steakhouse",
    location: "200 E Plume St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "glass-light",
    name: "Glass Light",
    category: "upscale",
    type: "French Fine Dining",
    location: "201 Granby St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "456-fish",
    name: "456 Fish",
    category: "upscale",
    type: "Seafood & Southern",
    location: "456 Granby St, Norfolk VA 23510",
    description: ""
  },

  // Healthy & Brunch
  {
    id: "stockpot-norfolk",
    name: "The Stockpot Norfolk",
    category: "healthy",
    type: "Healthy Comfort",
    location: "215 E Plume St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "degg-diner",
    name: "D'Egg Diner",
    category: "healthy",
    type: "Classic Brunch",
    location: "204 E Main St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "toast",
    name: "Toast",
    category: "healthy",
    type: "Creative Brunch",
    location: "2406 Colonial Ave, Norfolk VA 23517",
    description: ""
  },

  // Seafood Restaurants
  {
    id: "norfolk-seafood",
    name: "Norfolk Seafood Co & Oyster Bar",
    category: "seafood",
    type: "Seafood",
    location: "111 W Tazewell St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "stripers-waterside",
    name: "Stripers Waterside",
    category: "seafood",
    type: "Waterfront Seafood",
    location: "333 Waterside Dr, Norfolk VA 23510",
    description: ""
  },
  {
    id: "twisted-crab",
    name: "The Twisted Crab",
    category: "seafood",
    type: "Cajun Seafood",
    location: "4801 Hampton Blvd, Norfolk VA 23508",
    description: ""
  },

  // Mexican & Tex-Mex
  {
    id: "california-burrito",
    name: "California Burrito",
    category: "mexican",
    type: "Mexican",
    location: "335 Granby St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "panda-express",
    name: "Panda Express (MacArthur Center)",
    category: "mexican",
    type: "Fast-Casual Asian",
    location: "300 Monticello Ave, Norfolk VA 23510",
    description: ""
  },

  // Global Flavors
  {
    id: "saffron-indian",
    name: "Saffron Indian Bistro",
    category: "global",
    type: "Indian",
    location: "420 Monticello Ave, Norfolk VA 23510",
    description: ""
  },
  {
    id: "bonchon",
    name: "Bonchon",
    category: "global",
    type: "Korean Fusion",
    location: "273 Granby St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "yay-ya-gourmet",
    name: "Yay-Ya Gourmet",
    category: "global",
    type: "Asian Fusion",
    location: "261 Granby St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "voila-cuisine",
    name: "Voila Cuisine Internationale",
    category: "global",
    type: "Global Fine Dining",
    location: "509 Botetourt St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "luna-maya",
    name: "Luna Maya",
    category: "global",
    type: "Latin American",
    location: "2010 Colley Ave, Norfolk VA 23517",
    description: ""
  },

  // Breweries & Chill Bars
  {
    id: "grain",
    name: "Grain (5th Floor)",
    category: "breweries",
    type: "Rooftop Beer Garden",
    location: "100 E Main St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "brick-anchor",
    name: "Brick Anchor Brew House",
    category: "breweries",
    type: "Gastropub",
    location: "241 Granby St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "waters-edge",
    name: "Waters Edge Winery and Bistro",
    category: "breweries",
    type: "Winery",
    location: "257 Granby St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "grace-omalleys",
    name: "Grace O'Malley's Irish Pub",
    category: "breweries",
    type: "Irish Pub",
    location: "211 Granby St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "barrel-room",
    name: "The Barrel Room",
    category: "breweries",
    type: "Whiskey & Wine Bar",
    location: "437 Granby St, Norfolk VA 23510",
    description: ""
  },

  // Nightlife & Party Bars
  {
    id: "blue-moon",
    name: "Blue Moon Taphouse",
    category: "nightlife",
    type: "Sports Bar",
    location: "333 Waterside Dr, Norfolk VA 23510",
    description: ""
  },
  {
    id: "pbr-norfolk",
    name: "PBR Norfolk",
    category: "nightlife",
    type: "Country Bar",
    location: "333 Waterside Dr, Norfolk VA 23510",
    description: ""
  },
  {
    id: "circuit-social",
    name: "Circuit Social",
    category: "nightlife",
    type: "Arcade Bar",
    location: "258 Granby St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "play-norfolk",
    name: "Play Norfolk",
    category: "nightlife",
    type: "Retro Arcade",
    location: "278 Granby St, Norfolk VA 23510",
    description: ""
  },

  // Coffee Shops & Quick Bites
  {
    id: "town-center",
    name: "Town Center Cold Pressed (1st Floor)",
    category: "coffee",
    type: "Coffee & Juice Bar",
    location: "100 E Main St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "starbucks",
    name: "Starbucks",
    category: "coffee",
    type: "Coffee",
    location: "201 E Main St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "cafe-stella",
    name: "Cafe Stella",
    category: "coffee",
    type: "Local Coffee Shop",
    location: "116 Granby St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "cure-coffeehouse",
    name: "Cure Coffeehouse",
    category: "coffee",
    type: "Artisan Coffee",
    location: "503 Botetourt St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "neptunes-fury",
    name: "Neptune's Fury Coffee Company",
    category: "coffee",
    type: "Creative Coffee",
    location: "999 Waterside Dr, Norfolk VA 23510",
    description: ""
  },
  {
    id: "cream-coffee",
    name: "Cream (MacArthur Center)",
    category: "coffee",
    type: "Ice Cream",
    location: "300 Monticello Ave, Norfolk VA 23510",
    description: ""
  },
  {
    id: "cafe-crema",
    name: "Cafe Crema (MacArthur Center)",
    category: "coffee",
    type: "Coffee & Pastries",
    location: "300 Monticello Ave, Norfolk VA 23510",
    description: ""
  },

  // Sweets & Ice Cream
  {
    id: "cream",
    name: "Cream (MacArthur Center)",
    category: "sweets",
    type: "Ice Cream",
    location: "300 Monticello Ave, Norfolk VA 23510",
    description: ""
  },
  {
    id: "auntie-annes",
    name: "Auntie Anne's (MacArthur Center)",
    category: "sweets",
    type: "Pretzels",
    location: "300 Monticello Ave, Norfolk VA 23510",
    description: ""
  },
  {
    id: "baskin-robbins",
    name: "Baskin-Robbins",
    category: "sweets",
    type: "Ice Cream",
    location: "140 W 21st St, Norfolk VA 23517",
    description: ""
  },

  // Essentials & Services
  {
    id: "copy-connection",
    name: "Copy Connection",
    category: "essentials",
    type: "Printing & Office",
    location: "320 Granby St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "fedex-office",
    name: "FedEx Office Print & Ship Center",
    category: "essentials",
    type: "Shipping & Printing",
    location: "520 E Main St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "usps",
    name: "USPS Post Office",
    category: "essentials",
    type: "Postal Services",
    location: "600 Church St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "cvs",
    name: "CVS Pharmacy",
    category: "essentials",
    type: "Pharmacy & Convenience",
    location: "207 Granby St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "7-eleven",
    name: "7-Eleven",
    category: "essentials",
    type: "24/7 Convenience",
    location: "211 W 21st St, Norfolk VA 23517",
    description: ""
  },
  {
    id: "slover-library-essentials",
    name: "Slover Library",
    category: "essentials",
    type: "Library & Public Computers",
    location: "235 E Plume St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "norfolk-visitor-center",
    name: "Norfolk Visitor Center",
    category: "essentials",
    type: "Tourist Info",
    location: "232 E Main St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "atms",
    name: "ATMs",
    category: "essentials",
    type: "Cash Access",
    location: "100 E Main St & Various Locations, Norfolk VA 23510",
    description: ""
  },
  {
    id: "parking-garages",
    name: "Public Parking Garages",
    category: "essentials",
    type: "Parking",
    location: "E Main St & Various Locations, Norfolk VA 23510",
    description: ""
  },
  {
    id: "electric-bike-rentals",
    name: "Electric Bike Rentals",
    category: "essentials",
    type: "Bike Rentals",
    location: "333 Waterside Dr, Norfolk VA 23510",
    description: ""
  },

  // Attractions, Shopping & Things To Do
  {
    id: "nauticus",
    name: "Nauticus & Battleship Wisconsin",
    category: "attractions",
    type: "Naval Museum",
    location: "1 Waterside Dr, Norfolk VA 23510",
    description: ""
  },
  {
    id: "naval-museum",
    name: "Hampton Roads Naval Museum",
    category: "attractions",
    type: "Maritime History",
    location: "1 Waterside Dr, Norfolk VA 23510",
    description: ""
  },
  {
    id: "macarthur-memorial",
    name: "MacArthur Memorial",
    category: "attractions",
    type: "Military History",
    location: "198 Bank St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "town-point-park",
    name: "Town Point Park",
    category: "attractions",
    type: "Riverfront Park",
    location: "113 Waterside Dr, Norfolk VA 23510",
    description: ""
  },
  {
    id: "slover-library",
    name: "Slover Library",
    category: "attractions",
    type: "Library",
    location: "235 E Plume St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "selden-market",
    name: "Selden Market",
    category: "attractions",
    type: "Artisan Market",
    location: "208 E Main St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "macarthur-center",
    name: "MacArthur Center Mall",
    category: "attractions",
    type: "Shopping Mall",
    location: "300 Monticello Ave, Norfolk VA 23510",
    description: ""
  },
  {
    id: "norva",
    name: "The NorVa",
    category: "attractions",
    type: "Concert Venue",
    location: "317 Monticello Ave, Norfolk VA 23510",
    description: ""
  },
  {
    id: "wells-theatre",
    name: "Wells Theatre",
    category: "attractions",
    type: "Historic Theater",
    location: "108 E Tazewell St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "pagoda-garden",
    name: "Pagoda & Oriental Garden",
    category: "attractions",
    type: "Garden",
    location: "265 W Tazewell St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "freemason-district",
    name: "Freemason Historic District",
    category: "attractions",
    type: "Historic District",
    location: "Freemason St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "mermaid-statues",
    name: "Mermaid Statues & The Mermaid Factory",
    category: "attractions",
    type: "Public Art",
    location: "Various Locations, Norfolk VA 23510",
    description: ""
  },
  {
    id: "scavenger-hunts",
    name: "Self-Guided Scavenger Hunts",
    category: "attractions",
    type: "City Exploration",
    location: "Downtown Norfolk, Norfolk VA 23510",
    description: ""
  },
  {
    id: "waterside-district",
    name: "Waterside District",
    category: "attractions",
    type: "Entertainment District",
    location: "333 Waterside Dr, Norfolk VA 23510",
    description: ""
  },
  {
    id: "offsite-gallery",
    name: "Offsite Gallery (MacArthur Center)",
    category: "attractions",
    type: "Art Gallery",
    location: "300 Monticello Ave, Norfolk VA 23510",
    description: ""
  },
  {
    id: "push-comedy",
    name: "Push Comedy Theater",
    category: "attractions",
    type: "Comedy Shows",
    location: "763 Granby St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "hunter-house",
    name: "Hunter House Victorian Museum",
    category: "attractions",
    type: "Victorian Museum",
    location: "240 W Freemason St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "moses-myers-house",
    name: "Moses Myers House",
    category: "attractions",
    type: "Historic House",
    location: "323 E Freemason St, Norfolk VA 23510",
    description: ""
  },
  {
    id: "chrysler-museum",
    name: "Chrysler Museum of Art & Glass Studio",
    category: "attractions",
    type: "Art Museum",
    location: "1 Memorial Pl, Norfolk VA 23510",
    description: ""
  },
  {
    id: "neon-district",
    name: "NEON Arts District",
    category: "attractions",
    type: "Arts District",
    location: "Granby St & Virginia Beach Blvd, Norfolk VA 23510",
    description: ""
  },
  {
    id: "mlk-monument",
    name: "Martin Luther King Monument",
    category: "attractions",
    type: "Monument",
    location: "Church St & Brambleton Ave, Norfolk VA 23510",
    description: ""
  },
  {
    id: "st-pauls",
    name: "St. Paul's Episcopal Church",
    category: "attractions",
    type: "Historic Church",
    location: "201 St Paul's Blvd, Norfolk VA 23510",
    description: ""
  },

  // Medical & Emergency Services
  {
    id: "sentara-norfolk",
    name: "Sentara Norfolk General Hospital",
    category: "medical",
    type: "Full-Service Hospital",
    location: "600 Gresham Dr, Norfolk VA 23507",
    description: ""
  },
  {
    id: "chkd",
    name: "Children's Hospital of The King's Daughters (CHKD)",
    category: "medical",
    type: "Pediatric Hospital",
    location: "601 Children's Ln, Norfolk VA 23507",
    description: ""
  }
];