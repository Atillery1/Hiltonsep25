import { ReactNode } from "react";

export interface Restaurant {
  id: string;
  name: string;
  location: string;
  website: string;
  phone: string;
  operatingHours: {
    title: string;
    schedule: string[];
    note?: string;
  }[];
  happyHour?: {
    location?: string;
    schedule: string[];
  };
  inRoomDining?: {
    note?: string;
    schedule: string[];
  };
  noInRoomDining?: string;
}

export interface Amenity {
  id: string;
  name: string;
  location: string;
  hours: string;
  description: string;
  iconType: string; // String identifier instead of direct React component
}

export const restaurants: Restaurant[] = [
  {
    id: "saltine",
    name: "Saltine",
    location: "1st Floor",
    website: "saltinenorfolk.com",
    phone: "(757) 763-6280",
    operatingHours: [
      {
        title: "Lunch",
        schedule: ["Monday – Friday: 11:30 AM – 3:00 PM"]
      },
      {
        title: "Dinner",
        schedule: [
          "Sunday – Thursday: 5:00 PM – 11:00 PM",
          "Friday – Saturday: 5:00 PM – 12:00 AM"
        ],
        note: "Kitchen Closes: Same as posted hours"
      },
      {
        title: "Brunch",
        schedule: ["Saturday – Sunday: 10:00 AM – 3:00 PM"]
      }
    ],
    happyHour: {
      location: "Bar & Patio Only",
      schedule: ["Monday – Friday: 3:00 PM – 6:00 PM"]
    },
    inRoomDining: {
      note: "Saltine Menu",
      schedule: [
        "Lunch (Monday – Friday): 10:00 AM – 5:00 PM",
        "Brunch (Saturday – Sunday): 10:00 AM – 5:00 PM",
        "Dinner (Daily): 5:00 PM – 11:00 PM"
      ]
    }
  },
  {
    id: "varia",
    name: "Varia",
    location: "2nd Floor",
    website: "varianorfolk.com",
    phone: "(757) 763-6281",
    operatingHours: [
      {
        title: "Breakfast",
        schedule: ["Daily: 6:00 AM – 10:00 AM"]
      },
      {
        title: "Dinner",
        schedule: ["Tuesday – Saturday: 5:00 PM – 10:00 PM"],
        note: "Kitchen Closes: Tuesday – Saturday: 10:00 PM"
      },
      {
        title: "Brunch",
        schedule: ["Not available"]
      }
    ],
    happyHour: {
      location: "Wolf Lounge Only",
      schedule: ["Tuesday – Friday: 5:00 PM – 7:00 PM"]
    },
    inRoomDining: {
      note: "Breakfast Only",
      schedule: ["Daily: 6:00 AM – 10:00 AM"]
    }
  },
  {
    id: "grain",
    name: "Grain",
    location: "Rooftop – 5th Floor",
    website: "grainnorfolk.com",
    phone: "(757) 763-6279",
    operatingHours: [
      {
        title: "Lunch & Dinner",
        schedule: [
          "Monday – Thursday: 12:00 PM – 12:00 AM",
          "Friday: 12:00 PM – 2:00 AM",
          "Saturday: 4:00 PM – 2:00 AM",
          "Sunday: 4:00 PM – 12:00 AM"
        ]
      },
      {
        title: "Kitchen Closes",
        schedule: [
          "Sunday – Thursday: 12:00 AM",
          "Friday – Saturday: 1:00 AM"
        ]
      },
      {
        title: "Brunch Buffet",
        schedule: ["Saturday – Sunday: 9:00 AM – 3:00 PM"]
      }
    ],
    happyHour: {
      schedule: ["Monday – Friday: 3:00 PM – 5:00 PM"]
    },
    noInRoomDining: "Not Available"
  }
];

export const amenities: Amenity[] = [
  {
    id: "wifi",
    name: "Internet Connection",
    location: "Available throughout the hotel",
    hours: "Available 24/7",
    description: "Free Wi-Fi Access Instructions\nNetwork Name: HILTON HONORS\nUsername: Your Last Name\nPassword: Your Room Number",
    iconType: "Wifi"
  },
  {
    id: "market-pantry",
    name: "Market Pantry",
    location: "2nd floor (behind front desk)",
    hours: "Open 24 hours daily",
    description: "Convenient access to snacks, drinks, and essentials during your stay.",
    iconType: "ShoppingBag"
  },
  {
    id: "pool",
    name: "Pool",
    location: "5th floor",
    hours: "6am – 10pm daily",
    description: "Relax and unwind in our refreshing pool with panoramic views.",
    iconType: "Pool"
  },
  {
    id: "fitness-center",
    name: "Fitness Center",
    location: "5th floor",
    hours: "Open 24 hours daily",
    description: "State-of-the-art exercise equipment to maintain your fitness routine.",
    iconType: "Dumbbell"
  },
  {
    id: "business-center",
    name: "Business Center",
    location: "2nd floor next to front desk",
    hours: "Open 24 hours daily",
    description: "Full-service business center with computers, printers, and high-speed internet access.",
    iconType: "Laptop"
  }
];
