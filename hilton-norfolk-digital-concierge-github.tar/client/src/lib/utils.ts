import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import { Restaurant, Amenity } from "./hotelData"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Days of the week mapping for easier parsing of schedule strings
export const DAYS = {
  monday: 1,
  tuesday: 2,
  wednesday: 3,
  thursday: 4,
  friday: 5,
  saturday: 6,
  sunday: 0
}

// Parse time string (e.g., "10:00 AM", "6:30 PM", "10am", "6:30pm") to hours/minutes in 24h format
function parseTime(timeStr: string): { hour: number; minute: number } {
  let hour = 0;
  let minute = 0;
  
  // Strip any whitespace and convert to lowercase
  timeStr = timeStr.trim().toLowerCase();
  
  // Match different time formats - handle both "10:00 AM" and "10am" styles
  // This regex handles formats like "10:00 AM", "10:00AM", "10AM", "10am"
  const timeRegex = /(\d+)(?::(\d+))?\s*(am|pm)/i;
  const match = timeStr.match(timeRegex);
  
  if (match) {
    hour = parseInt(match[1], 10);
    minute = match[2] ? parseInt(match[2], 10) : 0;
    
    // Handle special cases like "12:00 AM" (midnight) and "12:00 PM" (noon)
    if (match[3].toLowerCase() === 'pm') {
      if (hour !== 12) hour += 12;  // 1:00 PM = 13:00, but 12:00 PM = 12:00
    } else if (match[3].toLowerCase() === 'am') {
      if (hour === 12) hour = 0;    // 12:00 AM = 00:00
    }
  }
  
  console.log(`Parsed time: ${timeStr} => ${hour}:${minute}`);
  return { hour, minute };
}

// Check if a restaurant is currently open
export function isRestaurantOpen(restaurant: Restaurant): boolean {
  // Get current time in Eastern Standard Time
  const now = new Date();
  // Convert to Eastern Time (ET)
  const etOptions = { timeZone: 'America/New_York' };
  const etDateString = now.toLocaleString('en-US', etOptions);
  const etDate = new Date(etDateString);
  
  const currentDay = etDate.getDay(); // 0 = Sunday, 1 = Monday, etc.
  const currentHour = etDate.getHours();
  const currentMinute = etDate.getMinutes();
  
  console.log(`Checking if ${restaurant.name} is open, current time: ${currentHour}:${currentMinute}`);
  
  // Special case for Grain which might have a different format
  if (restaurant.id === "grain") {
    console.log("Special handling for Grain");
    const isWeekend = currentDay === 0 || currentDay === 6; // 0 = Sunday, 6 = Saturday
    
    // Rooftop hours
    if (isWeekend) {
      // Saturday (4:00 PM - 2:00 AM) or Sunday (4:00 PM - 12:00 AM)
      const openTime = { hour: 16, minute: 0 }; // 4:00 PM
      const closeTime = currentDay === 0 ? { hour: 0, minute: 0 } : { hour: 2, minute: 0 }; // Sunday: 12:00 AM, Saturday: 2:00 AM
      
      const currentTimeInMinutes = currentHour * 60 + currentMinute;
      const openTimeInMinutes = openTime.hour * 60 + openTime.minute;
      const closeTimeInMinutes = closeTime.hour * 60 + closeTime.minute;
      
      // After opening time OR before closing time (for times that span midnight)
      if (currentTimeInMinutes >= openTimeInMinutes || currentTimeInMinutes <= closeTimeInMinutes) {
        console.log("Grain is open (weekend evening)");
        return true;
      }
      
      // Check for brunch hours on weekends (9:00 AM - 3:00 PM)
      if (currentHour >= 9 && currentHour < 15) {
        console.log("Grain is open (weekend brunch)");
        return true;
      }
    } else {
      // Weekday: Monday-Thursday (12:00 PM - 12:00 AM)
      if (currentDay >= 1 && currentDay <= 4) {
        if (currentHour >= 12) {
          console.log("Grain is open (Mon-Thu)");
          return true;
        }
      } 
      // Friday: (12:00 PM - 2:00 AM)
      else if (currentDay === 5) {
        if (currentHour >= 12 || currentHour < 2) {
          console.log("Grain is open (Friday)");
          return true;
        }
      }
    }
    
    console.log("Grain is closed");
    return false;
  }
  
  // Special case: Skip "Kitchen Closes" schedules for determining if restaurant is open
  // Kitchen Closes is an information element, not an operating hours indicator
  const operatingHours = restaurant.operatingHours.filter(
    hours => !hours.title.toLowerCase().includes('kitchen')
  );
  
  // Check each operating hours period
  for (const hours of operatingHours) {
    // Skip "Not available" schedules
    if (hours.schedule.some(s => s.toLowerCase().includes('not available'))) {
      continue;
    }
    
    for (const schedule of hours.schedule) {
      // Parse the schedule string (e.g., "Monday – Friday: 11:30 AM – 3:00 PM")
      // First, determine which days this applies to
      let applicableDays: number[] = [];
      
      if (schedule.toLowerCase().includes('daily')) {
        applicableDays = [0, 1, 2, 3, 4, 5, 6]; // All days
      } else if (schedule.toLowerCase().includes('weekend')) {
        applicableDays = [0, 6]; // Weekend days
      } else if (schedule.toLowerCase().includes('saturday') && schedule.toLowerCase().includes('sunday')) {
        applicableDays = [0, 6]; // Weekend days
      } else if (schedule.toLowerCase().includes('weekday') || 
                 (schedule.toLowerCase().includes('monday') && schedule.toLowerCase().includes('friday'))) {
        applicableDays = [1, 2, 3, 4, 5]; // Weekdays
      } else {
        // Parse specific days like "Tuesday – Saturday"
        const dayMatch = schedule.toLowerCase().match(/([a-z]+day)\s*(?:–|-|to)\s*([a-z]+day)/);
        if (dayMatch) {
          const startDay = DAYS[dayMatch[1].toLowerCase() as keyof typeof DAYS];
          const endDay = DAYS[dayMatch[2].toLowerCase() as keyof typeof DAYS];
          
          // Handle wrapping around the week (e.g., Sunday-Tuesday)
          if (startDay <= endDay) {
            for (let d = startDay; d <= endDay; d++) {
              applicableDays.push(d);
            }
          } else {
            // Handle wrap-around (e.g., Friday-Monday)
            for (let d = startDay; d <= 6; d++) {
              applicableDays.push(d);
            }
            for (let d = 0; d <= endDay; d++) {
              applicableDays.push(d);
            }
          }
        }
      }
      
      // If current day is not in the applicable days, skip this schedule
      if (!applicableDays.includes(currentDay)) {
        continue;
      }
      
      // Parse opening and closing times
      const timeRangeMatch = schedule.match(/(\d+(?::\d+)?\s*(?:AM|PM|am|pm))\s*(?:–|-|to)\s*(\d+(?::\d+)?\s*(?:AM|PM|am|pm))/i);
      if (timeRangeMatch) {
        const openTime = parseTime(timeRangeMatch[1]);
        const closeTime = parseTime(timeRangeMatch[2]);
        
        // Convert current time to minutes for easier comparison
        const currentTimeInMinutes = currentHour * 60 + currentMinute;
        const openTimeInMinutes = openTime.hour * 60 + openTime.minute;
        const closeTimeInMinutes = closeTime.hour * 60 + closeTime.minute;
        
        // Check if current time is within range
        // Handle cases where closing time is after midnight
        if (closeTimeInMinutes < openTimeInMinutes) { // e.g., 10pm - 2am
          if (currentTimeInMinutes >= openTimeInMinutes || 
              currentTimeInMinutes <= closeTimeInMinutes) {
            return true;
          }
        } else { // Normal case, e.g., 11am - 10pm
          if (currentTimeInMinutes >= openTimeInMinutes && 
              currentTimeInMinutes <= closeTimeInMinutes) {
            return true;
          }
        }
      }
    }
  }
  
  return false; // Not open in any of the defined time slots
}

// Check if room service is currently available for a restaurant
export function isRoomServiceAvailable(restaurant: Restaurant): boolean {
  if (!restaurant.inRoomDining) {
    return false;
  }
  
  // Get current time in Eastern Standard Time
  const now = new Date();
  // Convert to Eastern Time (ET)
  const etOptions = { timeZone: 'America/New_York' };
  const etDateString = now.toLocaleString('en-US', etOptions);
  const etDate = new Date(etDateString);
  
  const currentDay = etDate.getDay();
  const currentHour = etDate.getHours();
  const currentMinute = etDate.getMinutes();
  const currentTimeInMinutes = currentHour * 60 + currentMinute;
  
  console.log(`Checking room service for ${restaurant.name}, current time: ${currentHour}:${currentMinute}`);
  
  for (const schedule of restaurant.inRoomDining.schedule) {
    // Parse the schedule string similar to isRestaurantOpen
    let applicableDays: number[] = [];
    
    if (schedule.toLowerCase().includes('daily')) {
      applicableDays = [0, 1, 2, 3, 4, 5, 6]; // All days
    } else if (schedule.toLowerCase().includes('weekend')) {
      applicableDays = [0, 6]; // Weekend days
    } else if (schedule.toLowerCase().includes('saturday') && schedule.toLowerCase().includes('sunday')) {
      applicableDays = [0, 6]; // Weekend days
    } else if (schedule.toLowerCase().includes('weekday') || 
                (schedule.toLowerCase().includes('monday') && schedule.toLowerCase().includes('friday'))) {
      applicableDays = [1, 2, 3, 4, 5]; // Weekdays
    } else {
      // Parse specific days like "Monday – Friday"
      const dayMatch = schedule.toLowerCase().match(/([a-z]+day)\s*(?:–|-|to)\s*([a-z]+day)/);
      if (dayMatch) {
        const startDay = DAYS[dayMatch[1].toLowerCase() as keyof typeof DAYS];
        const endDay = DAYS[dayMatch[2].toLowerCase() as keyof typeof DAYS];
        
        if (startDay <= endDay) {
          for (let d = startDay; d <= endDay; d++) {
            applicableDays.push(d);
          }
        } else {
          for (let d = startDay; d <= 6; d++) {
            applicableDays.push(d);
          }
          for (let d = 0; d <= endDay; d++) {
            applicableDays.push(d);
          }
        }
      }
    }
    
    if (!applicableDays.includes(currentDay)) {
      console.log(`Day not applicable for schedule: ${schedule}`);
      continue;
    }
    
    // Extract time ranges like "10:00 AM – 5:00 PM"
    const timeRangeMatch = schedule.match(/(\d+(?::\d+)?\s*(?:AM|PM|am|pm))\s*(?:–|-|to)\s*(\d+(?::\d+)?\s*(?:AM|PM|am|pm))/i);
    if (timeRangeMatch) {
      const openTime = parseTime(timeRangeMatch[1]);
      const closeTime = parseTime(timeRangeMatch[2]);
      
      console.log(`Room service schedule: ${openTime.hour}:${openTime.minute} - ${closeTime.hour}:${closeTime.minute}`);
      
      const openTimeInMinutes = openTime.hour * 60 + openTime.minute;
      const closeTimeInMinutes = closeTime.hour * 60 + closeTime.minute;
      
      if (closeTimeInMinutes < openTimeInMinutes) { // e.g., 10:00 PM - 6:00 AM
        if (currentTimeInMinutes >= openTimeInMinutes || 
            currentTimeInMinutes <= closeTimeInMinutes) {
          console.log(`Room service available for ${restaurant.name}`);
          return true;
        }
      } else { // Normal case, e.g., 10:00 AM - 5:00 PM
        if (currentTimeInMinutes >= openTimeInMinutes && 
            currentTimeInMinutes <= closeTimeInMinutes) {
          console.log(`Room service available for ${restaurant.name}`);
          return true;
        }
      }
    } else {
      console.log(`No time range match in schedule: ${schedule}`);
    }
  }
  
  console.log(`No room service available for ${restaurant.name}`);
  return false;
}

// Get the currently available menu for room service
export function getCurrentRoomServiceMenu(restaurant: Restaurant): string {
  if (!restaurant.inRoomDining || !isRoomServiceAvailable(restaurant)) {
    return "";
  }
  
  // Get current time in Eastern Standard Time
  const now = new Date();
  // Convert to Eastern Time (ET)
  const etOptions = { timeZone: 'America/New_York' };
  const etDateString = now.toLocaleString('en-US', etOptions);
  const etDate = new Date(etDateString);
  
  const currentDay = etDate.getDay();
  const currentHour = etDate.getHours();
  const currentMinute = etDate.getMinutes();
  const currentTimeInMinutes = currentHour * 60 + currentMinute;
  
  // First, find the correct schedule that's active right now
  for (const schedule of restaurant.inRoomDining.schedule) {
    let applicableDays: number[] = [];
    
    // Determine if this schedule applies to today
    if (schedule.toLowerCase().includes('daily')) {
      applicableDays = [0, 1, 2, 3, 4, 5, 6]; // All days
    } else if (schedule.toLowerCase().includes('weekend')) {
      applicableDays = [0, 6]; // Weekend days
    } else if (schedule.toLowerCase().includes('saturday') && schedule.toLowerCase().includes('sunday')) {
      applicableDays = [0, 6]; // Weekend days
    } else if (schedule.toLowerCase().includes('weekday') || 
               (schedule.toLowerCase().includes('monday') && schedule.toLowerCase().includes('friday'))) {
      applicableDays = [1, 2, 3, 4, 5]; // Weekdays
    } else {
      // Parse specific days like "Monday – Friday"
      const dayMatch = schedule.toLowerCase().match(/([a-z]+day)\s*(?:–|-|to)\s*([a-z]+day)/);
      if (dayMatch) {
        const startDay = DAYS[dayMatch[1].toLowerCase() as keyof typeof DAYS];
        const endDay = DAYS[dayMatch[2].toLowerCase() as keyof typeof DAYS];
        
        if (startDay <= endDay) {
          for (let d = startDay; d <= endDay; d++) {
            applicableDays.push(d);
          }
        } else {
          for (let d = startDay; d <= 6; d++) {
            applicableDays.push(d);
          }
          for (let d = 0; d <= endDay; d++) {
            applicableDays.push(d);
          }
        }
      }
    }
    
    if (!applicableDays.includes(currentDay)) {
      continue;
    }
    
    // Now parse the time range to check if we're within service hours
    const timeRangeMatch = schedule.match(/(\d+(?::\d+)?\s*(?:AM|PM|am|pm))\s*(?:–|-|to)\s*(\d+(?::\d+)?\s*(?:AM|PM|am|pm))/i);
    if (timeRangeMatch) {
      const openTime = parseTime(timeRangeMatch[1]);
      const closeTime = parseTime(timeRangeMatch[2]);
      
      const openTimeInMinutes = openTime.hour * 60 + openTime.minute;
      const closeTimeInMinutes = closeTime.hour * 60 + closeTime.minute;
      
      // Check if current time falls within this range
      let isInRange = false;
      
      if (closeTimeInMinutes < openTimeInMinutes) { // e.g., 10:00 PM - 6:00 AM
        isInRange = currentTimeInMinutes >= openTimeInMinutes || 
                    currentTimeInMinutes <= closeTimeInMinutes;
      } else { // Normal case, e.g., 10:00 AM - 5:00 PM
        isInRange = currentTimeInMinutes >= openTimeInMinutes && 
                   currentTimeInMinutes <= closeTimeInMinutes;
      }
      
      if (isInRange) {
        // Now determine the meal type from the schedule description
        if (schedule.toLowerCase().includes('breakfast')) {
          return "Breakfast";
        } else if (schedule.toLowerCase().includes('brunch')) {
          return "Brunch";
        } else if (schedule.toLowerCase().includes('lunch')) {
          return "Lunch";
        } else if (schedule.toLowerCase().includes('dinner')) {
          return "Dinner";
        }
      }
    }
  }
  
  // Fallback: determine meal based on time of day
  if (currentHour >= 6 && currentHour < 11) {
    return "Breakfast";
  } else if (currentHour >= 11 && currentHour < 17) {
    return "Lunch";
  } else {
    return "Dinner";
  }
}

// Check if an amenity is currently open
export function isAmenityOpen(amenity: Amenity): boolean {
  // If the amenity is open 24 hours, return true immediately
  if (amenity.hours.toLowerCase().includes("24 hours")) {
    return true;
  }
  
  // Get current time in Eastern Standard Time
  const now = new Date();
  // Convert to Eastern Time (ET)
  const etOptions = { timeZone: 'America/New_York' };
  const etDateString = now.toLocaleString('en-US', etOptions);
  const etDate = new Date(etDateString);
  
  const currentDay = etDate.getDay(); // 0 = Sunday, 1 = Monday, etc.
  const currentHour = etDate.getHours();
  const currentMinute = etDate.getMinutes();
  
  // Parse hours like "6am – 10pm daily" or similar formats
  const timeRangeMatch = amenity.hours.match(/(\d+(?::\d+)?\s*(?:am|pm|AM|PM))\s*(?:–|-|to)\s*(\d+(?::\d+)?\s*(?:am|pm|AM|PM))/i);
  
  if (timeRangeMatch) {
    const openTime = parseTime(timeRangeMatch[1]);
    const closeTime = parseTime(timeRangeMatch[2]);
    
    const currentTimeInMinutes = currentHour * 60 + currentMinute;
    const openTimeInMinutes = openTime.hour * 60 + openTime.minute;
    const closeTimeInMinutes = closeTime.hour * 60 + closeTime.minute;
    
    // Handle cases where closing time is after midnight
    if (closeTimeInMinutes < openTimeInMinutes) { // e.g., 10pm - 2am
      return currentTimeInMinutes >= openTimeInMinutes || 
             currentTimeInMinutes <= closeTimeInMinutes;
    } else { // Normal case, e.g., 6am - 10pm
      return currentTimeInMinutes >= openTimeInMinutes && 
             currentTimeInMinutes <= closeTimeInMinutes;
    }
  }
  
  // Default to open if we can't parse the hours (to avoid showing "Closed" unnecessarily)
  return true;
}

// Determine which meal period is currently being served
export function getCurrentMealPeriod(restaurant: Restaurant): string {
  if (!isRestaurantOpen(restaurant)) {
    return "";
  }
  
  // Get current time in Eastern Standard Time
  const now = new Date();
  // Convert to Eastern Time (ET)
  const etOptions = { timeZone: 'America/New_York' };
  const etDateString = now.toLocaleString('en-US', etOptions);
  const etDate = new Date(etDateString);
  
  const currentDay = etDate.getDay(); // 0 = Sunday, 1 = Monday, etc.
  const currentHour = etDate.getHours();
  const currentMinute = etDate.getMinutes();
  const currentTimeInMinutes = currentHour * 60 + currentMinute;
  
  // Check each operating period to find which one is active now
  for (const hours of restaurant.operatingHours) {
    const title = hours.title;
    
    // Skip "Kitchen Closes" schedules - they're informational not meal periods
    if (title.toLowerCase().includes('kitchen')) {
      continue;
    }
    
    // Iterate through each schedule for this meal period
    for (const schedule of hours.schedule) {
      // Skip "Not available" schedules
      if (schedule.toLowerCase().includes('not available')) {
        continue;
      }
      
      // Determine if this schedule applies to today
      let applicableDays: number[] = [];
      
      if (schedule.toLowerCase().includes('daily')) {
        applicableDays = [0, 1, 2, 3, 4, 5, 6]; // All days
      } else if (schedule.toLowerCase().includes('weekend')) {
        applicableDays = [0, 6]; // Weekend days
      } else if (schedule.toLowerCase().includes('saturday') && schedule.toLowerCase().includes('sunday')) {
        applicableDays = [0, 6]; // Weekend days
      } else if (schedule.toLowerCase().includes('weekday') || 
                (schedule.toLowerCase().includes('monday') && schedule.toLowerCase().includes('friday'))) {
        applicableDays = [1, 2, 3, 4, 5]; // Weekdays
      } else {
        // Parse specific days like "Tuesday – Saturday"
        const dayMatch = schedule.toLowerCase().match(/([a-z]+day)\s*(?:–|-|to)\s*([a-z]+day)/);
        if (dayMatch) {
          const startDay = DAYS[dayMatch[1].toLowerCase() as keyof typeof DAYS];
          const endDay = DAYS[dayMatch[2].toLowerCase() as keyof typeof DAYS];
          
          if (startDay <= endDay) {
            for (let d = startDay; d <= endDay; d++) {
              applicableDays.push(d);
            }
          } else {
            for (let d = startDay; d <= 6; d++) {
              applicableDays.push(d);
            }
            for (let d = 0; d <= endDay; d++) {
              applicableDays.push(d);
            }
          }
        }
      }
      
      if (!applicableDays.includes(currentDay)) {
        continue;
      }
      
      // Parse time range
      const timeRangeMatch = schedule.match(/(\d+(?::\d+)?\s*(?:AM|PM|am|pm))\s*(?:–|-|to)\s*(\d+(?::\d+)?\s*(?:AM|PM|am|pm))/i);
      if (timeRangeMatch) {
        const openTime = parseTime(timeRangeMatch[1]);
        const closeTime = parseTime(timeRangeMatch[2]);
        
        const openTimeInMinutes = openTime.hour * 60 + openTime.minute;
        const closeTimeInMinutes = closeTime.hour * 60 + closeTime.minute;
        
        // Check if current time falls within this range
        let isInRange = false;
        
        if (closeTimeInMinutes < openTimeInMinutes) { // e.g., 10pm - 2am
          isInRange = currentTimeInMinutes >= openTimeInMinutes || 
                      currentTimeInMinutes <= closeTimeInMinutes;
        } else { // Normal case, e.g., 11am - 10pm
          isInRange = currentTimeInMinutes >= openTimeInMinutes && 
                     currentTimeInMinutes <= closeTimeInMinutes;
        }
        
        if (isInRange) {
          console.log(`Found current meal period for ${restaurant.name}: ${title}`);
          return title;
        }
      }
    }
  }
  
  // Default fallback based on time of day
  if (currentHour >= 5 && currentHour < 11) {
    return "Breakfast";
  } else if (currentHour >= 11 && currentHour < 16) {
    return "Lunch";
  } else if (currentHour >= 16 && currentHour < 23) {
    return "Dinner";
  } else {
    return "Late Night Menu";
  }
}
