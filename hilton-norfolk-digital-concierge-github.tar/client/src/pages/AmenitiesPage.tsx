import NewHeader from "@/components/NewHeader";
import AmenitiesSection from "@/components/AmenitiesSection";
import BottomNavigation from "@/components/BottomNavigation";
import { useEffect } from "react";

export default function AmenitiesPage() {
  useEffect(() => {
    // Scroll to top when page loads
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-[#F5F5F5] text-[#333333] font-[Raleway]">
      <NewHeader />
      <div className="py-4 bg-[#0F2C59] text-white text-center">
        <h1 className="text-2xl font-bold">Hotel Amenities</h1>
      </div>
      <main className="flex-grow pb-16">
        <div className="max-w-lg mx-auto px-4 py-6">
          {/* Amenities Section */}
          <AmenitiesSection />
        </div>
      </main>
      <BottomNavigation />
    </div>
  );
}