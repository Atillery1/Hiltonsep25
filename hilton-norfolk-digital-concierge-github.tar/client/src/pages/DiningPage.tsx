import NewHeader from "@/components/NewHeader";
import RestaurantSection from "@/components/RestaurantSection";
import RestaurantStatusSection from "@/components/RestaurantStatusSection";
import BottomNavigation from "@/components/BottomNavigation";
import { useEffect } from "react";
import { Clock } from "lucide-react";

export default function DiningPage() {
  useEffect(() => {
    // Scroll to top when page loads
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-[#F5F5F5] text-[#333333] font-[Raleway]">
      <NewHeader />
      <div className="py-4 bg-[#0F2C59] text-white text-center">
        <h1 className="text-2xl font-bold">Dining</h1>
      </div>
      <main className="flex-grow pb-16">
        <div className="max-w-lg mx-auto px-4 py-6">
          <RestaurantSection />
          
          {/* Restaurant Status Section at the bottom */}
          <div className="mt-6 mb-8">
            <div className="py-3 bg-[#0F2C59] text-white text-center rounded-md shadow-sm mb-4">
              <h3 className="text-xl font-bold flex items-center justify-center">
                <Clock className="mr-2 h-5 w-5 text-[#DBA53A]" />
                Currently Open
              </h3>
            </div>
            <RestaurantStatusSection />
          </div>
        </div>
      </main>
      <BottomNavigation />
    </div>
  );
}