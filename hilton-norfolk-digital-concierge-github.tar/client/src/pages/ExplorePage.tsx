import { useEffect, useState, useMemo } from 'react';
import NewHeader from "@/components/NewHeader";
import BottomNavigation from "@/components/BottomNavigation";
import { MapPin, Search } from 'lucide-react';
import { exploreCategories, exploreListings } from '@/lib/exploreData';
import ExploreCategoryFilter from '@/components/ExploreCategoryFilter';
import ExploreCategoryAccordion from '@/components/ExploreCategoryAccordion';
import ExploreSearchBar from '@/components/ExploreSearchBar';

export default function ExplorePage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  
  useEffect(() => {
    // Scroll to top when page loads
    window.scrollTo(0, 0);
  }, []);

  // Filter listings based on search term and selected category
  const filteredListings = useMemo(() => {
    let filtered = exploreListings;
    
    // Filter by search term
    if (searchTerm) {
      const lowerSearchTerm = searchTerm.toLowerCase();
      filtered = filtered.filter(listing => 
        listing.name.toLowerCase().includes(lowerSearchTerm) ||
        listing.type.toLowerCase().includes(lowerSearchTerm) ||
        listing.description.toLowerCase().includes(lowerSearchTerm)
      );
    }
    
    // Filter by category
    if (selectedCategory) {
      filtered = filtered.filter(listing => 
        listing.category === selectedCategory
      );
    }
    
    return filtered;
  }, [searchTerm, selectedCategory]);

  // Group listings by category
  const groupedListings = useMemo(() => {
    const grouped = exploreCategories.map(category => {
      const categoryListings = filteredListings.filter(
        listing => listing.category === category.id
      );
      
      return {
        category,
        listings: categoryListings
      };
    });
    
    // Only include categories that have listings after filtering
    return grouped.filter(group => group.listings.length > 0);
  }, [filteredListings]);

  const handleSearch = (term: string) => {
    setSearchTerm(term);
    // Clear category selection when searching
    if (term) {
      setSelectedCategory(null);
    }
  };
  
  const handleSelectCategory = (categoryId: string | null) => {
    setSelectedCategory(categoryId);
    // Clear search when selecting a category
    if (categoryId) {
      setSearchTerm('');
    }
  };
  
  // Count total filtered listings
  const totalFilteredListings = filteredListings.length;

  return (
    <div className="min-h-screen flex flex-col bg-[#F5F5F5] text-[#333333] font-[Raleway]">
      <NewHeader />
      <div className="py-4 bg-[#0F2C59] text-white text-center">
        <h1 className="text-2xl font-bold">Explore Norfolk</h1>
      </div>
      
      <main className="flex-grow pb-16">
        <div className="max-w-lg mx-auto px-4 py-6">
          <section id="explore">
            {/* Search Bar */}
            <div className="mb-6">
              <ExploreSearchBar onSearch={handleSearch} />
            </div>
            
            {/* Categories Filter */}
            <div className="sticky top-0 z-10 bg-[#F5F5F5] pt-2 pb-4 -mt-2">
              <ExploreCategoryFilter 
                categories={exploreCategories}
                selectedCategory={selectedCategory}
                onSelectCategory={handleSelectCategory}
              />
            </div>
            
            {/* Results Count */}
            <div className="mb-4 text-center">
              <p className="text-sm text-gray-600">
                {searchTerm || selectedCategory ? (
                  <>
                    <span className="font-semibold">{totalFilteredListings}</span> 
                    {' '}results found
                  </>
                ) : (
                  <>Discover the best of downtown Norfolk</>
                )}
              </p>
            </div>
            
            {/* No Results Message */}
            {groupedListings.length === 0 && (
              <div className="py-12 text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 mb-4 rounded-full bg-gray-100">
                  <Search className="h-8 w-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-semibold text-gray-700 mb-2">No results found</h3>
                <p className="text-gray-500 max-w-xs mx-auto">
                  We couldn't find anything matching your search. Try different keywords or browse by category.
                </p>
              </div>
            )}
            
            {/* Category Sections */}
            <div className="space-y-6">
              {groupedListings.map(({ category, listings }) => (
                <ExploreCategoryAccordion 
                  key={category.id}
                  category={category}
                  listings={listings}
                  isInitiallyOpen={
                    // Open if it's the selected category or there's a search term
                    selectedCategory === category.id || 
                    (searchTerm !== '' && listings.length > 0)
                  }
                />
              ))}
            </div>
            
            {/* Local Tip Section */}
            <div className="mt-8 p-5 bg-blue-50 border border-blue-100 rounded-lg">
              <div className="flex items-start">
                <div className="rounded-full p-2 bg-blue-100 mr-3 mt-0.5">
                  <MapPin className="h-5 w-5 text-blue-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800 mb-1">Local Tip</h3>
                  <p className="text-sm text-gray-600">
                    Most downtown attractions are within a 10-15 minute walk from the hotel.
                    Several dining options and amenities are located right in our hotel for your convenience.
                  </p>
                </div>
              </div>
            </div>
          </section>
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}