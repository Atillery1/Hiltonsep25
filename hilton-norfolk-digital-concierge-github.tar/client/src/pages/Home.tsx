import NewHeader from "@/components/NewHeader";
import BottomNavigation from "@/components/BottomNavigation";
import FeedbackSection from "@/components/FeedbackSection";
import { Link } from "wouter";
import { useEffect, useState } from "react";
import { 
  Utensils, 
  Clock,
  ChevronRight, 
  Coffee, 
  ChefHat,
  Beer,
  Phone,
  Info
} from "lucide-react";
import { restaurants } from "@/lib/hotelData";
import { DAYS, isRestaurantOpen, isRoomServiceAvailable, getCurrentMealPeriod } from "@/lib/utils";

export default function Home() {
  // Current time state
  const [currentTime, setCurrentTime] = useState<string>(
    new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  );
  
  // Update time every minute
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    }, 60000);
    
    return () => clearInterval(timer);
  }, []);
  
  useEffect(() => {
    // Scroll to top when page loads
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-[#F5F5F5] text-[#333333] font-[Raleway]">
      <NewHeader />
      <div className="flex-grow pb-16 bg-[#F5F5F5]"> 
        {/* Welcome Section */}
        <section className="bg-gradient-to-b from-[#0F2C59] to-[#1A3A6C] text-white py-8">
          <div className="max-w-2xl mx-auto px-4">
            <div className="text-center">
              <h1 className="text-3xl md:text-4xl font-bold font-['Playfair_Display'] mb-3 text-center">
                Welcome to <span className="text-[#DBA53A]">Hilton Norfolk The Main</span>
              </h1>
              <div className="h-0.5 w-32 bg-[#DBA53A] mx-auto mb-4 shadow-md shadow-[#DBA53A]/30"></div>
              <p className="mx-auto text-gray-100 text-base text-center leading-relaxed">
                Your complete guide to our hotel's finest dining, premium amenities, and exceptional services. 
                We're committed to making every moment of your stay truly memorable.
              </p>
            </div>
          </div>
        </section>
        
        {/* Restaurant Status Section */}
        <div className="max-w-lg mx-auto px-4 -mt-6">
          <div className="bg-white shadow-md rounded-md overflow-hidden">
            <div className="border-b border-gray-100 flex justify-between items-center px-6 py-4">
              <h2 className="font-bold text-lg text-[#0F2C59] flex items-center">
                <Utensils className="mr-2 h-5 w-5 text-[#0F2C59]" />
                Open Now
              </h2>
              <div className="text-sm text-gray-500">
                {currentTime}
              </div>
            </div>
            
            {/* Restaurant Status Cards */}
            <div className="p-5">
              <div className="divide-y divide-gray-100">
                {/* Dynamic Restaurant Cards */}
                {restaurants.map((restaurant) => {
                  const isOpen = isRestaurantOpen(restaurant);
                  const mealPeriod = isOpen ? getCurrentMealPeriod(restaurant) : "";
                  const hasRoomService = isRoomServiceAvailable(restaurant);
                  
                  // For kitchen closing time
                  const kitchenHours = restaurant.operatingHours.find(h => 
                    h.title.toLowerCase().includes('kitchen')
                  );
                  
                  // Find current operating hours for closing time
                  const currentDay = new Date().getDay(); // 0 = Sunday, 1 = Monday, etc.
                  let closingTime = "";
                  
                  // Use hardcoded closing times for accuracy and consistency
                  if (restaurant.id === "saltine") {
                    closingTime = "11:00 PM"; // Fixed closing time for Saltine
                  } else if (restaurant.id === "varia") {
                    closingTime = "10:00 PM"; // Fixed closing time for Varia
                  } else if (restaurant.id === "grain") {
                    // Grain's closing time varies by day of week
                    if (currentDay === 5 || currentDay === 6) { // Friday or Saturday
                      closingTime = "2:00 AM";
                    } else {
                      closingTime = "12:00 AM";
                    }
                  }
                  
                  // Get next opening time if closed
                  let nextOpeningTime = "";
                  if (!isOpen) {
                    // Find the next opening time
                    const currentHour = new Date().getHours();
                    const currentMinute = new Date().getMinutes();
                    const currentTimeInMinutes = currentHour * 60 + currentMinute;
                    
                    // For simplicity, just show the next available opening time
                    if (restaurant.id === "varia") {
                      // Varia's breakfast or dinner time
                      const now = new Date();
                      const currentDay = now.getDay();
                      
                      // Check if today is Tuesday-Saturday for dinner service
                      if (currentDay >= 2 && currentDay <= 6) {
                        // If current time is before 5 PM, show "Opens at 5:00 PM today"
                        if (currentTimeInMinutes < 17 * 60) {
                          nextOpeningTime = "Opens 5:00 PM today";
                        } else {
                          // Show breakfast time for tomorrow
                          nextOpeningTime = "Opens 6:30 AM tomorrow";
                        }
                      } else {
                        // Not a dinner service day, just show breakfast time
                        if (currentTimeInMinutes < 6 * 60 + 30) {
                          nextOpeningTime = "Opens 6:30 AM today";
                        } else if (currentTimeInMinutes < 10 * 60) {
                          nextOpeningTime = "Open now for Breakfast";
                        } else {
                          nextOpeningTime = "Opens 6:30 AM tomorrow";
                        }
                      }
                    } else if (restaurant.id === "saltine") {
                      // For Saltine, check if it's breakfast, lunch, or dinner time
                      const now = new Date();
                      const currentDay = now.getDay();
                      const isWeekend = currentDay === 0 || currentDay === 6;
                      
                      if (isWeekend) {
                        // Weekend brunch and dinner
                        if (currentTimeInMinutes < 10 * 60) {
                          nextOpeningTime = "Opens 10:00 AM today (Brunch)";
                        } else if (currentTimeInMinutes < 15 * 60) {
                          nextOpeningTime = "Open now for Brunch";
                        } else if (currentTimeInMinutes < 17 * 60) {
                          nextOpeningTime = "Opens 5:00 PM today (Dinner)";
                        } else {
                          nextOpeningTime = "Open now for Dinner";
                        }
                      } else {
                        // Weekday lunch and dinner
                        if (currentTimeInMinutes < 11 * 60 + 30) {
                          nextOpeningTime = "Opens 11:30 AM today (Lunch)";
                        } else if (currentTimeInMinutes < 15 * 60) {
                          nextOpeningTime = "Open now for Lunch";
                        } else if (currentTimeInMinutes < 17 * 60) {
                          nextOpeningTime = "Opens 5:00 PM today (Dinner)";
                        } else {
                          nextOpeningTime = "Open now for Dinner";
                        }
                      }
                    } else if (restaurant.id === "grain") {
                      // Grain's times
                      const now = new Date();
                      const currentDay = now.getDay();
                      const isWeekday = currentDay >= 1 && currentDay <= 5;
                      const isWeekend = currentDay === 0 || currentDay === 6;
                      
                      if (isWeekend) {
                        // Weekend schedule
                        if (currentDay === 6 || currentDay === 0) { // Saturday and Sunday
                          if (currentTimeInMinutes < 9 * 60) {
                            nextOpeningTime = "Opens 9:00 AM today (Brunch)";
                          } else if (currentTimeInMinutes < 15 * 60) {
                            nextOpeningTime = "Open now for Brunch";
                          } else if (currentTimeInMinutes < 16 * 60) {
                            nextOpeningTime = "Opens 4:00 PM today";
                          } else {
                            nextOpeningTime = "Open now";
                          }
                        }
                      } else {
                        // Weekday schedule
                        if (currentTimeInMinutes < 12 * 60) {
                          nextOpeningTime = "Opens 12:00 PM today";
                        } else {
                          nextOpeningTime = "Open now";
                        }
                      }
                    }
                  }
                  
                  // Get kitchen closing time
                  let kitchenClosingTime = "";
                  if (kitchenHours && kitchenHours.schedule.length > 0) {
                    // Find applicable schedule for today
                    for (const schedule of kitchenHours.schedule) {
                      let isToday = false;
                      
                      if (schedule.toLowerCase().includes('daily')) {
                        isToday = true;
                      } else if (schedule.toLowerCase().includes('sunday') && currentDay === 0) {
                        isToday = true;
                      } else if (schedule.toLowerCase().includes('friday') && schedule.toLowerCase().includes('saturday') && (currentDay === 5 || currentDay === 6)) {
                        isToday = true;
                      } else if (schedule.toLowerCase().includes('sunday') && schedule.toLowerCase().includes('thursday') && (currentDay >= 0 && currentDay <= 4)) {
                        isToday = true;
                      }
                      
                      if (isToday) {
                        const timeMatch = schedule.match(/(\d+(?::\d+)?\s*(?:AM|PM|am|pm))/i);
                        if (timeMatch) {
                          kitchenClosingTime = timeMatch[1];
                          break;
                        }
                      }
                    }
                  } else if (restaurant.id === "saltine") {
                    // For Saltine, kitchen closes same as posted hours
                    kitchenClosingTime = closingTime;
                  }
                  
                  // Icons based on restaurant type
                  let Icon = Coffee;
                  if (restaurant.id === "saltine") Icon = ChefHat;
                  if (restaurant.id === "grain") Icon = Beer;
                  
                  return (
                    <div
                      key={restaurant.id}
                      className={`py-4 flex items-center justify-between ${!isOpen ? 'opacity-60' : ''}`}
                    >
                      <div>
                        <div className="flex items-center">
                          <h3 className={`font-bold ${isOpen ? 'text-gray-800' : 'text-gray-500'}`}>
                            {restaurant.name}
                          </h3>
                          <span className={`ml-2 px-2 py-0.5 text-xs font-medium ${isOpen 
                            ? 'bg-[#0F2C59] text-white' 
                            : 'bg-gray-200 text-gray-600'}`}
                          >
                            {isOpen ? 'OPEN' : 'CLOSED'}
                          </span>
                        </div>
                        {/* Service Status Line: Closes only */}
                        <div className="flex items-center mt-1 text-xs">
                          {isOpen ? (
                            <span className="text-gray-500">
                              Closes {closingTime}
                            </span>
                          ) : (
                            <span className="text-gray-400">
                              {nextOpeningTime}
                            </span>
                          )}
                        </div>
                      </div>
                      
                      {/* Right side status info */}
                      {isOpen && (
                        <div className="text-right">
                          {/* Room service status for Saltine and Varia */}
                          {(restaurant.id === "saltine" || restaurant.id === "varia") && (
                            <div className="text-sm text-[#DBA53A] font-medium">
                              {hasRoomService ? "Room Service Available" : "No Room Service"}
                            </div>
                          )}
                          
                          {/* Only show kitchen closing for Grain */}
                          {restaurant.id === "grain" && kitchenClosingTime && (
                            <div className="text-xs text-gray-500 mt-1">
                              Kitchen closes at {kitchenClosingTime}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
              
              {/* Footer with disclaimer and link to more details */}
              <div className="mt-5 pt-4 border-t border-gray-100">
                <div className="text-xs text-gray-500 mb-2">
                  Restaurant hours may change due to business needs. Open/close notifications are based on standard hours.
                </div>
                <div className="flex items-center justify-between">
                  <div className="text-xs text-gray-500">
                    Updates automatically
                  </div>
                  <Link href="/dining">
                    <button className="px-4 py-2 text-sm text-[#0F2C59] border border-[#0F2C59] hover:bg-[#0F2C59] hover:text-white transition-colors flex items-center font-medium rounded-sm">
                      All Dining Options
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
          
          {/* Feedback Section */}
          <div className="mt-6 px-4 max-w-lg mx-auto">
            <FeedbackSection />
          </div>
        </div>
      </div>
      
      {/* Only Bottom Navigation, No Footer */}
      <BottomNavigation />
    </div>
  );
}
