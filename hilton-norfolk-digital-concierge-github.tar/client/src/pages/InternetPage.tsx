import NewHeader from "@/components/NewHeader";
import InternetSection from "@/components/InternetSection";
import BottomNavigation from "@/components/BottomNavigation";
import { useEffect } from "react";

export default function InternetPage() {
  useEffect(() => {
    // Scroll to top when page loads
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-[#F5F5F5] text-[#333333] font-[Raleway]">
      <NewHeader />
      <div className="py-4 bg-[#0F2C59] text-white text-center">
        <h1 className="text-2xl font-bold">Internet Access</h1>
      </div>
      <div className="flex-grow pb-16"> {/* Add padding for bottom navigation */}
        <InternetSection />
      </div>
      <BottomNavigation />
    </div>
  );
}